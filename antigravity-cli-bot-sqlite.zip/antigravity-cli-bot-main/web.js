'use strict';
/**
 * web.js — Server Mini App "Task Map".
 *
 * - Menyajikan webapp/index.html dan API JSON (/api/state, /api/task/:id) dari SQLite.
 * - Autentikasi (salah satu):
 *     1. Telegram Mini App : header X-Telegram-Init-Data divalidasi HMAC dengan BOT_TOKEN,
 *                            dan user.id harus ada di ALLOWED_CHAT_ID.
 *     2. Kunci admin       : ?key=... atau header X-Admin-Key (untuk buka lewat http://IP:PORT di browser).
 * - Tanpa dependensi tambahan (modul http bawaan Node).
 *
 * CATATAN: Telegram hanya mau membuka Mini App lewat HTTPS. Lewat http://IP:PORT, gunakan
 * tombol "buka di browser" (kunci admin) atau pasang reverse proxy HTTPS (lihat README).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const INDEX_FILE = path.join(__dirname, 'webapp', 'index.html');

function safeEqual(a, b) {
    const x = Buffer.from(String(a));
    const y = Buffer.from(String(b));
    return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/** Validasi initData Telegram Mini App. Mengembalikan objek user atau null. */
function verifyInitData(initData, botToken, maxAgeSec = 24 * 3600) {
    try {
        const params = new URLSearchParams(initData);
        const hash = params.get('hash');
        if (!hash) return null;
        params.delete('hash');

        const dataCheckString = [...params.entries()]
            .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
            .map(([k, v]) => k + '=' + v)
            .join('\n');
        const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
        const calc = crypto.createHmac('sha256', secret).update(dataCheckString).digest('hex');
        if (!safeEqual(calc, hash)) return null;

        const authDate = parseInt(params.get('auth_date'), 10);
        if (!authDate || Date.now() / 1000 - authDate > maxAgeSec) return null;

        return JSON.parse(params.get('user') || 'null');
    } catch (_) {
        return null;
    }
}

function trunc(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

const eventPublic = (e, full) => ({
    step: e.step_index,
    kind: e.kind,
    tool: e.tool,
    icon: e.icon,
    title: e.title,
    short: e.short,
    target: e.target,
    state: e.state,
    ok: e.ok == null ? null : !!e.ok,
    durationMs: e.duration_ms,
    startedMs: e.started_ms,
    updatedMs: e.updated_ms,
    ...(full ? { params: e.params, output: e.output } : {}),
});

const taskPublic = (t) => ({
    id: t.id,
    status: t.status,
    prompt: trunc(t.prompt, 160),
    model: t.model,
    account: t.account,
    toolCount: t.tool_count,
    tokens: t.tokens,
    error: t.error,
    startedAt: t.started_at,
    finishedAt: t.finished_at,
    conversationId: t.conversation_id,
});

function start({ port, botToken, allowedIds, adminKey, store, getInfo }) {
    const failures = new Map(); // ip -> { n, since }

    // X-Forwarded-For hanya dipercaya bila request datang dari reverse proxy lokal (Caddy/nginx),
    // kalau tidak penyerang bisa memalsukannya untuk menghindari pembatasan percobaan.
    const clientIp = (req) => {
        const remote = req.socket.remoteAddress || '';
        const local = remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1';
        return local && req.headers['x-forwarded-for']
            ? String(req.headers['x-forwarded-for']).split(',')[0].trim()
            : remote;
    };

    const blocked = (ip) => {
        const f = failures.get(ip);
        if (!f) return false;
        if (Date.now() - f.since > 10 * 60 * 1000) { failures.delete(ip); return false; }
        return f.n >= 20;
    };
    const fail = (ip) => {
        const f = failures.get(ip);
        if (!f || Date.now() - f.since > 10 * 60 * 1000) failures.set(ip, { n: 1, since: Date.now() });
        else f.n++;
    };

    function authorize(req, url) {
        const key = req.headers['x-admin-key'] || url.searchParams.get('key');
        if (key && adminKey && safeEqual(key, adminKey)) return { via: 'key' };

        const init = req.headers['x-telegram-init-data'];
        if (init && allowedIds.length) {
            const user = verifyInitData(String(init), botToken);
            if (user && allowedIds.includes(String(user.id))) return { via: 'telegram', user };
        }
        return null;
    }

    function sendJson(res, code, obj) {
        const body = JSON.stringify(obj);
        res.writeHead(code, {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store',
            'X-Content-Type-Options': 'nosniff',
        });
        res.end(body);
    }

    const server = http.createServer((req, res) => {
        try {
            const url = new URL(req.url, 'http://localhost');
            const ip = clientIp(req);

            if (req.method !== 'GET' && req.method !== 'HEAD') {
                res.writeHead(405); return res.end();
            }

            if (url.pathname === '/' || url.pathname === '/index.html') {
                res.writeHead(200, {
                    'Content-Type': 'text/html; charset=utf-8',
                    'Cache-Control': 'no-store',
                    'X-Content-Type-Options': 'nosniff',
                    'Referrer-Policy': 'no-referrer',
                });
                return res.end(fs.readFileSync(INDEX_FILE));
            }

            if (url.pathname === '/healthz') {
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                return res.end('ok');
            }

            if (url.pathname.startsWith('/api/')) {
                if (blocked(ip)) return sendJson(res, 429, { error: 'terlalu banyak percobaan' });
                const auth = authorize(req, url);
                if (!auth) { fail(ip); return sendJson(res, 401, { error: 'unauthorized' }); }

                if (url.pathname === '/api/state') {
                    const tasks = store.listTasks(12);
                    const wanted = parseInt(url.searchParams.get('task'), 10);
                    const sel = tasks.find(t => t.id === wanted) || tasks.find(t => t.status === 'running') || tasks[0] || null;
                    return sendJson(res, 200, {
                        now: Date.now(),
                        info: getInfo(),
                        tasks: tasks.map(taskPublic),
                        selected: sel ? {
                            task: taskPublic(sel),
                            events: store.getTaskEvents(sel.id, 300).map(e => eventPublic(e, true)),
                        } : null,
                    });
                }

                return sendJson(res, 404, { error: 'not found' });
            }

            res.writeHead(404); res.end();
        } catch (e) {
            console.error('[web] error:', e.message);
            try { res.writeHead(500); res.end(); } catch (_) {}
        }
    });

    server.on('error', (e) => console.error('[web] Gagal membuka port ' + port + ': ' + e.message));
    server.listen(port, '0.0.0.0', () => console.log('[web] Task Map aktif di port ' + port));
    return server;
}

module.exports = { start, verifyInitData };
