# 🌌 Antigravity CLI Telegram Bot

> **Ultra-lightweight, High-Performance Telegram Bot wrapper for native Google Antigravity CLI (`agy`)**.  
> Terhubung langsung ke mesin resmi Google Antigravity CLI di VPS tanpa browser emulator/Electron yang berat. Hemat RAM (~70MB), responsif, dan siap produksi.

---

## ⚡ Fitur Utama

- 🚀 **100% Native CLI Execution:** Terintegrasi langsung dengan binary resmi Google Antigravity CLI (`agy v1.5.0`), bukan web automation/CDP yang memakan resource.
- 👥 **Multi-Account Manager (`/accounts`, `/login`):** Dukungan banyak akun Google AI Pro. Ganti akun aktif secara instan dengan inline button, lengkap dengan penukar kode otorisasi OAuth otomatis dan auto-refresh token.
- 💬 **Advanced Session Continuation & Custom Session ID (`/sessions`, `/session`):**
  - AI mengingat konteks percakapan antar pesan secara berkelanjutan.
  - Tampilan daftar riwayat sesi lengkap dengan judul, total obrolan, tanggal dalam waktu WIB, dan tombol sekali klik untuk berpindah sesi.
  - Dukungan **Custom Session ID**: Pengguna dapat memasukkan UUID sesi lama atau memberi nama alias kustom sendiri (contoh: `/session projek-bot`).
- 🎨 **Rich Aesthetic Markdown Formatter:** Output bot diformat rapi menggunakan Telegram HTML modern (tanpa simbol markdown mentah `**` atau `###`), dilengkapi aksen header (`🔹`, `📌`), garis pembatas rapi, bullet points bertingkat, blockquotes, dan syntax highlighting code blocks.
- 📎 **File & Document Analysis:**
  - Menerima semua jenis file: Gambar/Foto, Dokumen (*.pdf, *.txt, *.js, *.py, *.json*), Audio, Video, serta Arsip (*.zip, *.tar.gz*).
  - Cukup **reply pesan file** dengan instruksi Anda, atau isi langsung di kolom caption saat mengirim file.
- 📸 **Web Screenshot (`/screenshot <url>`):** Otomatis membuka URL halaman website secara headless dan mengirimkan foto tangkapan layar langsung ke Telegram.
- 🗄️ **Penyimpanan SQLite:** Pengaturan chat (model, mode, sesi aktif), alias sesi, akun Google, dan riwayat percakapan disimpan di satu file `data/bot.db` (tidak lagi di file JSON / RAM), jadi tetap aman saat bot restart. Data JSON lama (`accounts.json`, `session_aliases.json`) dimigrasikan otomatis saat bot pertama kali jalan. Memakai modul bawaan `node:sqlite` (Node.js ≥ 22.5), tanpa dependensi native.
- 🛡️ **Zero Useless Commands:** Menu command Telegram telah disinkronkan bersih di semua scope (tidak ada lagi command sisa yang tidak berfungsi).
- 🔄 **Auto-Restart & Persistence:** Berjalan di latar belakang via **PM2** dengan restart otomatis saat terjadi crash atau VPS reboot.

---

## 🚀 Panduan Instalasi (1x Command Langsung Jalan)

### Cara Cepat (One-Line Auto Deploy)

Jalankan perintah ini di VPS Anda (Ubuntu / Debian x86_64 / arm64):

```bash
git clone https://github.com/berusigma/antigravity-cli-bot.git
cd antigravity-cli-bot
chmod +x install.sh
./install.sh
```

Skrip `install.sh` akan secara otomatis:
1. Memperbarui paket sistem dan menginstal dependensi dasar (`git`, `unzip`, `curl`, `python3`).
2. Memasang **Node.js 22 LTS** dan **PM2**.
3. Mengunduh dan memasang resmi **Google Antigravity CLI (`agy`)**.
4. Memasang seluruh dependensi npm dan Chromium Headless untuk fitur screenshot.
5. Memandu pembuatan file `.env` untuk `BOT_TOKEN` dan `ALLOWED_CHAT_ID`.
6. Menjalankan bot di background via PM2 dengan status online.

---

### Instalasi Manual (Langkah demi Langkah)

Jika Anda ingin mengonfigurasi secara manual:

```bash
# 1. Clone repository
git clone https://github.com/berusigma/antigravity-cli-bot.git
cd antigravity-cli-bot

# 2. Salin dan edit konfigurasi .env
cp .env.example .env
nano .env

# 3. Pasang dependensi
npm install
npx puppeteer browsers install chrome --install-deps

# 4. Jalankan bot via PM2
pm2 start index.js --name agy-bot --node-args="--disable-warning=ExperimentalWarning"
pm2 save
pm2 startup
```

---

## ⚙️ Konfigurasi Environment (`.env`)

```ini
# Token Bot Telegram dari @BotFather
BOT_TOKEN=1234567890:ABCdefGhIJKlmNoPQRsTUVwxyZ

# Chat ID Telegram Anda yang diizinkan mengakses bot (kosongkan jika publik)
ALLOWED_CHAT_ID=8618058517

# Model AI Default
DEFAULT_MODEL=gemini-3.8-flash-high

# Mode Eksekusi CLI Default (accept-edits / plan)
DEFAULT_MODE=accept-edits

# (Opsional) Lokasi database SQLite. Default: ./data/bot.db
# DB_PATH=/root/antigravity-cli-bot/data/bot.db
```

---

## 📖 Daftar Perintah Bot Telegram

| Perintah | Deskripsi |
| :--- | :--- |
| `/start` | Memulai bot dan menampilkan ringkasan status sistem |
| `/help` | Menampilkan panduan penggunaan dan seluruh fitur bot |
| `/sessions` | Melihat daftar lengkap riwayat sesi obrolan dengan navigasi halaman |
| `/session <id/nama>` | Beralih ke UUID sesi tertentu atau memberi nama sesi kustom sendiri |
| `/new` | Memulai sesi obrolan baru dari awal (mereset konteks) |
| `/history [n]` | Melihat n pesan terakhir (default 6) dari sesi aktif, diambil dari SQLite |
| `/export` | Mengunduh seluruh riwayat sesi aktif sebagai file `.md` |
| `/accounts` | Mengelola dan mengganti akun Google AI Pro yang aktif |
| `/login` | Menambahkan akun Google baru melalui alur Google OAuth |
| `/model` | Memilih model AI (*Gemini 3.8 Flash, Claude Sonnet 4.6, Claude Opus 4.6, GPT-OSS 120B*) |
| `/mode` | Memilih mode agen (*accept-edits* untuk langsung eksekusi atau *plan* untuk perencanaan) |
| `/screenshot <url>` | Mengambil gambar tangkapan layar website (contoh: `/screenshot https://google.com`) |
| `/stop` | Membatalkan / menghentikan proses eksekusi agy yang sedang berjalan |
| `/status` | Melihat penggunaan memori RAM VPS, akun aktif, dan sesi saat ini |

---

## 🛠️ Manajemen Proses (PM2)

```bash
# Cek status bot
pm2 status agy-bot

# Melihat log bot secara real-time
pm2 logs agy-bot

# Restart bot
pm2 restart agy-bot

# Menghentikan bot
pm2 stop agy-bot
```

---

## 📄 Lisensi
Repository ini dilisensikan di bawah [MIT License](LICENSE).
