#!/usr/bin/env bash
# ==============================================================================
# Antigravity CLI Telegram Bot - One-Command Auto Deployer
# ==============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "=========================================================="
echo "   🚀 ANTIGRAVITY CLI TELEGRAM BOT - AUTO INSTALLER      "
echo "=========================================================="
echo -e "${NC}"

# 1. Root check
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}⚠️ Skrip ini direkomendasikan dijalankan sebagai root.${NC}"
fi

# 2. Update packages & install system requirements
echo -e "${BLUE}📦 [1/6] Memperbarui paket sistem & dependensi dasar...${NC}"
if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y curl wget git unzip python3 build-essential libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2t64 2>/dev/null || apt-get install -y curl wget git unzip python3 build-essential libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2 2>/dev/null || true
fi

# 3. Check or Install Node.js 22 LTS
echo -e "${BLUE}🟢 [2/6] Memeriksa instalasi Node.js...${NC}"
NODE_OK=0
if command -v node >/dev/null 2>&1; then
    NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    NODE_MINOR=$(node -v | cut -d'v' -f2 | cut -d'.' -f2)
    # Butuh Node >= 22.5 karena bot memakai modul bawaan node:sqlite
    if [ "$NODE_VER" -gt 22 ] || { [ "$NODE_VER" -eq 22 ] && [ "$NODE_MINOR" -ge 5 ]; }; then
        NODE_OK=1
        echo -e "${GREEN}✓ Node.js $(node -v) sudah terpasang.${NC}"
    fi
fi

if [ "$NODE_OK" -eq 0 ]; then
    echo -e "${YELLOW}Mengunduh & memasang Node.js 22 LTS...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
fi

# 4. Install PM2
echo -e "${BLUE}⚙️  [3/6] Memasang PM2 Process Manager...${NC}"
if ! command -v pm2 >/dev/null 2>&1; then
    npm install -g pm2
else
    echo -e "${GREEN}✓ PM2 sudah terpasang.${NC}"
fi

# 5. Check or Install Google Antigravity CLI (agy)
echo -e "${BLUE}🌌 [4/6] Memeriksa Google Antigravity CLI (agy)...${NC}"
if ! command -v agy >/dev/null 2>&1; then
    echo -e "${YELLOW}Memasang native Antigravity CLI...${NC}"
    curl -fsSL https://antigravity.google/cli/install.sh | bash
    if [ -f "$HOME/.local/bin/agy" ]; then
        ln -sf "$HOME/.local/bin/agy" /usr/local/bin/agy 2>/dev/null || true
    fi
else
    echo -e "${GREEN}✓ Antigravity CLI ($(agy --help 2>&1 | head -n 1)) siap.${NC}"
fi

# 6. Install Project Dependencies & Headless Chrome
echo -e "${BLUE}📚 [5/6] Memasang dependensi npm & Headless Chrome...${NC}"
npm install

echo -e "${BLUE}Mengunduh Chrome untuk fitur Screenshot...${NC}"
npx puppeteer browsers install chrome --install-deps || true

# 7. Setup .env Configuration
echo -e "${BLUE}🔐 [6/6] Menyiapkan konfigurasi environment (.env)...${NC}"
if [ ! -f .env ]; then
    if [ -n "$BOT_TOKEN" ] && [ -n "$ALLOWED_CHAT_ID" ]; then
        echo "BOT_TOKEN=$BOT_TOKEN" > .env
        echo "ALLOWED_CHAT_ID=$ALLOWED_CHAT_ID" >> .env
        echo "DEFAULT_MODEL=gemini-3.8-flash-high" >> .env
        echo "DEFAULT_MODE=accept-edits" >> .env
        echo -e "${GREEN}✓ File .env dibuat dari variabel environment.${NC}"
    else
        echo -e "${YELLOW}Silakan masukkan kredensial bot Telegram Anda:${NC}"
        read -rp "👉 Masukkan BOT_TOKEN dari @BotFather: " input_token
        read -rp "👉 Masukkan Chat ID Telegram Anda: " input_chat_id
        echo "BOT_TOKEN=${input_token}" > .env
        echo "ALLOWED_CHAT_ID=${input_chat_id}" >> .env
        echo "DEFAULT_MODEL=gemini-3.8-flash-high" >> .env
        echo "DEFAULT_MODE=accept-edits" >> .env
        echo -e "${GREEN}✓ File .env berhasil dibuat!${NC}"
    fi
else
    echo -e "${GREEN}✓ File .env sudah ada.${NC}"
fi

# Ensure workspace folders
mkdir -p /root/workspace/uploads

# 7b. Task Map (mini app): port, IP publik & firewall
echo -e "${BLUE}🗺️  Menyiapkan Task Map (mini app)...${NC}"
[ -n "$(tail -c1 .env 2>/dev/null)" ] && echo >> .env
ensure_env() { grep -q "^$1=" .env 2>/dev/null || echo "$1=$2" >> .env; }
ensure_env WEBAPP_PORT "${WEBAPP_PORT:-8080}"
PUB_IP=$(curl -s --max-time 5 https://api.ipify.org || true)
[ -n "$PUB_IP" ] && ensure_env PUBLIC_IP "$PUB_IP"
TM_PORT=$(grep '^WEBAPP_PORT=' .env | cut -d= -f2)
TM_IP=$(grep '^PUBLIC_IP=' .env | cut -d= -f2)
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow "${TM_PORT}/tcp" >/dev/null 2>&1 && echo -e "${GREEN}✓ Firewall: port ${TM_PORT} dibuka.${NC}"
fi

# 8. Start with PM2
echo -e "${CYAN}🚀 Menjalankan bot dengan PM2...${NC}"
pm2 delete agy-bot 2>/dev/null || true
pm2 start index.js --name agy-bot --node-args="--disable-warning=ExperimentalWarning"
pm2 save

echo ""
echo -e "${GREEN}==========================================================${NC}"
echo -e "${GREEN}   ✅ ANTIGRAVITY TELEGRAM BOT BERHASIL DIAKTIFKAN!       ${NC}"
echo -e "${GREEN}==========================================================${NC}"
echo -e "• Status PM2   : $(pm2 jlist | grep -o '\"status\":\"online\"' | head -n 1)"
echo -e "• Cek Log      : pm2 logs agy-bot"
echo -e "• Restart      : pm2 restart agy-bot"
echo -e "• Stop         : pm2 stop agy-bot"
echo -e "• Task Map     : http://${TM_IP:-IP_VPS}:${TM_PORT:-8080}  (ketik /app di bot untuk link + kunci akses)"
echo ""
echo -e "Buka Telegram Anda dan ketik ${CYAN}/start${NC} di bot untuk mulai!"
