require('dotenv').config();
const { Telegraf, Markup } = require('telegraf');
const { spawn, exec } = require('child_process');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const store = require('./db');

const BOT_TOKEN = process.env.BOT_TOKEN;
const ALLOWED_CHAT_IDS = (process.env.ALLOWED_CHAT_ID || '').split(',').map(s => s.trim()).filter(Boolean);
const DEFAULT_MODEL = process.env.DEFAULT_MODEL || 'gemini-3.8-flash-high';
const DEFAULT_MODE = process.env.DEFAULT_MODE || 'accept-edits';
const AGY_PATH = '/usr/local/bin/agy';
const WORKSPACE_DIR = '/root/workspace';
const UPLOADS_DIR = path.join(WORKSPACE_DIR, 'uploads');
const LEGACY_ALIASES_FILE = '/root/antigravity-cli-bot/session_aliases.json';
const AGY_DB_PATH = process.env.AGY_DB_PATH || '/root/.gemini/antigravity-cli/conversation_summaries.db';
const BACKUP_REPO_URL = process.env.BACKUP_REPO_URL || 'https://github.com/berusigma/antigravity-sessions-backup';
const BACKUP_SCRIPT_PATH = process.env.BACKUP_SCRIPT_PATH || '/root/.gemini/backup_sessions.py';

function triggerSessionBackup() {
    if (fs.existsSync(BACKUP_SCRIPT_PATH)) {
        console.log('[backup] Triggering automatic session backup...');
        exec(`python3 "${BACKUP_SCRIPT_PATH}"`, (err, stdout, stderr) => {
            if (err) {
                console.error('[backup] Auto-backup error:', err.message);
            } else {
                console.log('[backup] Auto-backup synchronized successfully to GitHub.');
            }
        });
    }
}

fs.mkdirSync(WORKSPACE_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Google OAuth Constants
const GOOGLE_CLIENT_ID = '1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';
const OAUTH_SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/cclog',
    'https://www.googleapis.com/auth/experimentsandconfigs'
].join(' ');

const LEGACY_ACCOUNTS_JSON = '/root/antigravity-cli-bot/accounts.json';
const LEGACY_ACCOUNTS_FILE = '/root/.gemini/antigravity/tg_accounts.json';
const AGY_TOKEN_PATHS = [
    '/root/.gemini/antigravity-cli/antigravity-oauth-token',
    '/root/.gemini/antigravity/antigravity-oauth-token',
    '/root/.gemini/antigravity-oauth-token'
];

if (!BOT_TOKEN) {
    console.error('Fatal: BOT_TOKEN is missing in .env');
    process.exit(1);
}

// Migrasi satu kali: file JSON lama -> SQLite
store.migrateFromJson({
    aliasesFile: LEGACY_ALIASES_FILE,
    accountsFile: LEGACY_ACCOUNTS_JSON,
    legacyAccountsFile: LEGACY_ACCOUNTS_FILE,
});

// ─── Session Aliases Manager ──────────────────────────────────────────────────

function loadAliases() {
    return store.loadAliases();
}

function saveAlias(name, convoId) {
    try {
        store.saveAlias(name, convoId);
    } catch (e) {
        console.error('Failed to save alias:', e);
    }
}

// ─── Markdown to Beautiful Telegram HTML ──────────────────────────────────────

// Buang escape sequence ANSI (warna terminal) & karakter kontrol dari output CLI
const ANSI_RE = /\x1b\[[0-9;?]*[ -\/]*[@-~]/g;
function cleanCliOutput(text) {
    return String(text || '')
        .replace(ANSI_RE, '')
        .replace(/\r\n?/g, '\n')
        .replace(/[ \t]+$/gm, '')
        .trim();
}

function beautifyMarkdown(text) {
    if (!text) return '';

    // 1. Extract code blocks (use safe tokens without markdown chars)
    const codeBlocks = [];
    let s = text.replace(/```([a-zA-Z0-9_+#.-]*)[ \t]*\n?([\s\S]*?)```/g, (m, lang, code) => {
        const id = codeBlocks.length;
        const esc = code.replace(/\n+$/, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const langAttr = lang ? ` class="language-${lang}"` : '';
        codeBlocks.push(`<pre><code${langAttr}>${esc}</code></pre>`);
        return `@@@CB${id}@@@`;
    });

    // 2. Extract inline code
    const inlineCodes = [];
    s = s.replace(/`([^`\n]+)`/g, (m, code) => {
        const id = inlineCodes.length;
        const esc = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        inlineCodes.push(`<code>${esc}</code>`);
        return `@@@IC${id}@@@`;
    });

    // 3. Escape HTML entities on remaining text
    s = s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // 4. Format markdown tables to clean mobile key-value rows
    s = s.replace(/(?:^\|[^\n]+\|\r?\n(?:\|[ :|-]+\|\r?\n)?(?:\|[^\n]+\|\r?\n?)+)/gm, (tableBlock) => {
        const lines = tableBlock.trim().split('\n').filter(l => l.trim().startsWith('|'));
        if (lines.length < 2) return tableBlock;

        const parseRow = (line) => line.split('|').slice(1, -1).map(c => c.trim());
        const headers = parseRow(lines[0]);
        let startIdx = 1;
        if (lines[1] && /^\|[\s:|-]+\|?$/.test(lines[1].trim())) {
            startIdx = 2;
        }

        const formattedRows = [];
        for (let i = startIdx; i < lines.length; i++) {
            const cells = parseRow(lines[i]);
            const rowDesc = cells.map((cell, cIdx) => {
                const h = headers[cIdx] ? `<b>${headers[cIdx]}:</b> ` : '';
                return `${h}${cell}`;
            }).join(' • ');
            formattedRows.push(`▫️ ${rowDesc}`);
        }
        return '\n' + formattedRows.join('\n') + '\n';
    });

    // 5. Convert Markdown Links: [text](url)
    s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (m, linkText, url) => {
        const cleanUrl = url.trim().replace(/&amp;/g, '&');
        // Discard useless file:// links on Telegram mobile
        if (cleanUrl.startsWith('file://')) {
            if (linkText.includes('@@@IC')) {
                return linkText;
            }
            return `<code>${linkText}</code>`;
        }
        if (/^(https?|tg):\/\//.test(cleanUrl)) {
            return `<a href="${cleanUrl.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">${linkText}</a>`;
        }
        return `<b>${linkText}</b>`;
    });

    // 6. Blockquotes: baris berurutan "> ..." digabung jadi satu kutipan
    //    (tanda > sudah di-escape menjadi &gt; pada langkah 3)
    s = s.replace(/(?:^&gt;[ \t]?.*(?:\n|$))+/gm, (blk) => {
        const lines = blk.replace(/\n$/, '').split('\n').map(l => l.replace(/^&gt;[ \t]?/, ''));
        const tag = lines.length > 6 ? '<blockquote expandable>' : '<blockquote>';
        return tag + lines.join('\n') + '</blockquote>\n';
    });

    // 7. Aesthetic Headers (order: h6 down to h1)
    s = s.replace(/^#{5,6}\s*(.+)$/gm, '\n▫️ <b>$1</b>');
    s = s.replace(/^####\s*(.+)$/gm, '\n🔹 <b>$1</b>');
    s = s.replace(/^###\s*(.+)$/gm, '\n🔹 <b>$1</b>');
    s = s.replace(/^##\s*(.+)$/gm, '\n🔷 <b>$1</b>');
    s = s.replace(/^#\s*(.+)$/gm, '\n📌 <b>$1</b>');

    // 8. Horizontal rules
    s = s.replace(/^[ \t]*([-*_])(?:[ \t]*\1){2,}[ \t]*$/gm, '───────────────');

    // 9. Task list & bullets (sebelum italic supaya "* item" tidak dianggap miring)
    s = s.replace(/^([ \t]*)[-*+]\s+\[ \]\s+/gm, '$1☐ ');
    s = s.replace(/^([ \t]*)[-*+]\s+\[[xX]\]\s+/gm, '$1☑️ ');
    s = s.replace(/^(?: {2,}|\t+)[-*+]\s+/gm, '   ▫️ ');
    s = s.replace(/^[ \t]*[-*+]\s+/gm, '• ');

    // 10. Strikethrough ~~text~~
    s = s.replace(/~~(.+?)~~/g, '<s>$1</s>');

    // 11. Bold & Italic combined: ***text***
    s = s.replace(/\*\*\*(.+?)\*\*\*/g, '<b><i>$1</i></b>');

    // 12. Bold: **text**
    s = s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');

    // 13. Italic: *text* or _text_
    s = s.replace(/(^|[^\w*])\*([^*\n]+?)\*(?=[^\w*]|$)/g, '$1<i>$2</i>');
    s = s.replace(/(^|[^\w])_([^_\n]+?)_(?=[^\w]|$)/g, '$1<i>$2</i>');

    // 14. Restore inline code and code blocks safely
    inlineCodes.forEach((val, i) => {
        s = s.split(`@@@IC${i}@@@`).join(val);
    });
    codeBlocks.forEach((val, i) => {
        s = s.split(`@@@CB${i}@@@`).join(val);
    });

    return s.replace(/\n{3,}/g, '\n\n').trim();
}

function stripMarkdown(text) {
    if (!text) return '';
    return text
        .replace(/```[a-zA-Z0-9_+#.-]*\n?([\s\S]*?)```/g, '$1')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, (m, txt, url) => {
            if (url.startsWith('file://')) return txt;
            return `${txt} (${url})`;
        })
        .replace(/\*\*\*([^*]+)\*\*\*/g, '$1')
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/\*([^*]+)\*/g, '$1')
        .replace(/^#{1,6}\s*/gm, '')
        .replace(/^[-*_]{3,}\s*$/gm, '───────────────')
        .replace(/^(\s{2,}|\t)[-*+]\s+/gm, '   - ')
        .replace(/^[\s]*[-*+]\s+/gm, '• ');
}

/**
 * Pecah teks Markdown (SEBELUM diformat) menjadi potongan ≤ max karakter.
 * Memutus di baris kosong bila bisa, dan bila pemutusan terjadi di dalam blok kode,
 * blok itu ditutup lalu dibuka lagi di potongan berikutnya, jadi tag <pre> tidak pernah patah.
 */
function splitMarkdown(text, max) {
    const lines = text.split('\n');
    const chunks = [];
    let cur = [];
    let curLen = 0;
    let fence = null; // null = di luar blok kode, selain itu = nama bahasa

    const flush = () => {
        if (!cur.length) return;
        chunks.push(cur.join('\n') + (fence !== null ? '\n```' : ''));
        cur = fence !== null ? ['```' + fence] : [];
        curLen = cur.length ? cur[0].length + 1 : 0;
    };

    for (const line of lines) {
        const isFence = /^\s*```/.test(line);
        const pieces = line.length > max
            ? line.match(new RegExp('[\\s\\S]{1,' + max + '}', 'g'))
            : [line];

        for (const piece of pieces) {
            const overflow = curLen + piece.length + 1 > max;
            if (cur.length && overflow && !(isFence && fence !== null)) {
                flush();
            } else if (cur.length && fence === null && piece.trim() === '' && curLen > max * 0.7) {
                flush();
                continue;
            }
            cur.push(piece);
            curLen += piece.length + 1;
        }
        if (isFence) fence = fence === null ? line.trim().slice(3).trim() : null;
    }
    flush();
    return chunks.filter(c => c.trim());
}

async function replyHtml(ctx, html, rawFallback, plainSuffix = '') {
    try {
        return await ctx.reply(html, {
            parse_mode: 'HTML',
            link_preview_options: { is_disabled: true }
        });
    } catch (e) {
        console.warn('[bot] HTML parse failed, falling back to plain text:', e.message);
        return await ctx.reply(stripMarkdown(rawFallback) + plainSuffix);
    }
}

function buildFooter({ model, durationMs, email }) {
    const bits = [];
    if (model) bits.push('⚡ ' + escapeHtml(model));
    if (durationMs != null) bits.push('⏱ ' + formatDuration(durationMs));
    if (email) bits.push('👤 ' + escapeHtml(email.split('@')[0]));
    return bits.length ? '<i>' + bits.join(' • ') + '</i>' : '';
}

function formatDuration(ms) {
    const sec = Math.round(ms / 1000);
    if (sec < 60) return sec + ' dtk';
    return Math.floor(sec / 60) + ' mnt ' + (sec % 60) + ' dtk';
}

async function sendFormattedLongMessage(ctx, text, footerHtml = '') {
    const clean = cleanCliOutput(text);
    const parts = [];

    // Hasil format HTML bisa lebih panjang dari teks mentah (escape &, <, >), jadi
    // potongan yang melewati batas Telegram (4096) dipecah lagi lebih kecil.
    const build = (raw, max) => {
        for (const piece of splitMarkdown(raw, max)) {
            const html = beautifyMarkdown(piece);
            if (html.length > 3900 && piece.length > 300) {
                build(piece, Math.max(200, Math.floor(max / 2)));
            } else {
                parts.push({ raw: piece, html });
            }
        }
    };
    build(clean, 3200);

    const footerPlain = footerHtml ? '\n\n' + footerHtml.replace(/<[^>]+>/g, '') : '';
    let last = null;

    for (let i = 0; i < parts.length; i++) {
        const isLast = i === parts.length - 1;
        let html = parts[i].html;
        let suffix = '';
        if (parts.length > 1) {
            html = `<i>📄 Bagian ${i + 1}/${parts.length}</i>\n\n` + html;
        }
        if (isLast && footerHtml) {
            if ((html + '\n\n' + footerHtml).length <= 4000) {
                html += '\n\n' + footerHtml;
                suffix = footerPlain;
            } else {
                last = await replyHtml(ctx, html, parts[i].raw);
                return await ctx.reply(footerHtml, { parse_mode: 'HTML' }).catch(() => last);
            }
        }
        last = await replyHtml(ctx, html, parts[i].raw, suffix);
    }
    return last;
}

// ─── Account Manager ──────────────────────────────────────────────────────────

function loadAccountsData() {
    return store.loadAccountsData();
}

function saveAccountsData(data) {
    try {
        store.saveAccountsData(data);
    } catch (e) {
        console.error('Failed to save accounts to SQLite:', e);
    }
}

async function refreshGoogleToken(refreshToken) {
    const res = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            client_id: GOOGLE_CLIENT_ID,
            client_secret: GOOGLE_CLIENT_SECRET,
            refresh_token: refreshToken,
            grant_type: 'refresh_token'
        })
    });
    const data = await res.json();
    if (!res.ok || !data.access_token) {
        throw new Error(data.error_description || data.error || 'Token refresh failed');
    }
    return data;
}

async function activateAccount(accountId) {
    const data = loadAccountsData();
    const acc = data.accounts[accountId];
    if (!acc) throw new Error('Akun #' + accountId + ' tidak ditemukan.');

    const refreshToken = acc.token?.refresh_token;
    if (!refreshToken) throw new Error('Refresh token akun #' + accountId + ' tidak ada.');

    const refreshed = await refreshGoogleToken(refreshToken);
    acc.token.access_token = refreshed.access_token;
    acc.token.expires_in = refreshed.expires_in || 3599;
    acc.token.expiry_timestamp = Math.floor(Date.now() / 1000) + (refreshed.expires_in || 3599);
    acc.updatedAt = Math.floor(Date.now() / 1000);

    data.activeId = String(accountId);
    saveAccountsData(data);

    const oauthPayload = JSON.stringify({
        token: {
            access_token: acc.token.access_token,
            token_type: 'Bearer',
            refresh_token: refreshToken,
            expiry: new Date(Date.now() + (acc.token.expires_in || 3599) * 1000).toISOString(),
            expires_in: acc.token.expires_in || 3599
        },
        auth_method: 'consumer',
        id_token_email: acc.email
    }, null, 2);

    for (const p of AGY_TOKEN_PATHS) {
        try {
            fs.mkdirSync(path.dirname(p), { recursive: true });
            fs.writeFileSync(p, oauthPayload, 'utf8');
        } catch (e) {
            console.error('Error writing token to ' + p + ':', e);
        }
    }

    return acc;
}

function getActiveAccount() {
    const data = loadAccountsData();
    const acc = data.accounts[data.activeId];
    return { id: data.activeId, account: acc };
}

// ─── OAuth Flow Server ────────────────────────────────────────────────────────

let activeOAuthSession = null;

async function startOAuthFlow(chatId) {
    if (activeOAuthSession?.server) {
        try { activeOAuthSession.server.close(); } catch (_) {}
    }

    const state = crypto.randomBytes(16).toString('hex');
    const ports = [8888, 8889, 8890, 8891];
    let boundPort = null;
    let server = null;

    for (const p of ports) {
        try {
            server = http.createServer();
            await new Promise((resolve, reject) => {
                server.once('error', reject);
                server.listen(p, '0.0.0.0', () => resolve());
            });
            boundPort = p;
            break;
        } catch (_) {
            if (server) try { server.close(); } catch (e) {}
        }
    }

    if (!boundPort) boundPort = 8888;
    const redirectUri = 'http://localhost:' + boundPort + '/oauth-callback';

    const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
        client_id: GOOGLE_CLIENT_ID,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: OAUTH_SCOPES,
        access_type: 'offline',
        prompt: 'consent',
        state: state
    }).toString();

    const sessionObj = {
        state,
        port: boundPort,
        redirectUri,
        server,
        chatId,
        createdAt: Date.now()
    };

    activeOAuthSession = sessionObj;

    if (server) {
        server.on('request', async (req, res) => {
            const reqUrl = new URL(req.url, 'http://localhost:' + boundPort);
            if (reqUrl.pathname === '/oauth-callback') {
                const code = reqUrl.searchParams.get('code');
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end('<h1>✅ Autentikasi Berhasil!</h1><p>Anda dapat menutup halaman ini dan kembali ke Telegram.</p>');
                if (code) {
                    handleAuthCode(code, redirectUri, chatId);
                }
            } else {
                res.writeHead(404);
                res.end();
            }
        });
    }

    return { authUrl, redirectUri };
}

async function handleAuthCode(rawCode, redirectUri, chatId) {
    const code = rawCode.trim();
    if (!code) return;

    try {
        const res = await fetch('https://oauth2.googleapis.com/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                client_id: GOOGLE_CLIENT_ID,
                client_secret: GOOGLE_CLIENT_SECRET,
                code: code,
                grant_type: 'authorization_code',
                redirect_uri: redirectUri
            })
        });

        const tokenData = await res.json();
        if (!res.ok || !tokenData.access_token) {
            throw new Error(tokenData.error_description || tokenData.error || 'Token exchange failed');
        }

        let email = 'unknown@google.com';
        let name = 'Google User';
        try {
            const uRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
                headers: { Authorization: 'Bearer ' + tokenData.access_token }
            });
            const uData = await uRes.json();
            if (uData.email) email = uData.email;
            if (uData.name) name = uData.name;
        } catch (_) {}

        const data = loadAccountsData();
        const existingId = Object.keys(data.accounts).find(k => data.accounts[k].email === email);
        const newId = existingId || (Object.keys(data.accounts).length > 0 ? String(Math.max(...Object.keys(data.accounts).map(Number)) + 1) : '1');

        data.accounts[newId] = {
            numericId: Number(newId),
            email: email,
            name: name,
            addedAt: Math.floor(Date.now() / 1000),
            updatedAt: Math.floor(Date.now() / 1000),
            token: {
                access_token: tokenData.access_token,
                refresh_token: tokenData.refresh_token,
                expires_in: tokenData.expires_in || 3599,
                expiry_timestamp: Math.floor(Date.now() / 1000) + (tokenData.expires_in || 3599),
                token_type: 'Bearer'
            }
        };

        saveAccountsData(data);
        await activateAccount(newId);

        if (activeOAuthSession?.server) {
            try { activeOAuthSession.server.close(); } catch (_) {}
            activeOAuthSession = null;
        }

        await bot.telegram.sendMessage(chatId, 
            '🎉 <b>Akun Berhasil Ditambahkan & Diaktifkan!</b>\n\n' +
            '📧 <b>Email:</b> <code>' + escapeHtml(email) + '</code>\n' +
            '🆔 <b>ID Akun:</b> #' + newId + '\n\n' +
            'Sekarang bot Antigravity CLI langsung menggunakan akun ini.',
            { parse_mode: 'HTML' }
        );
    } catch (err) {
        console.error('Error in handleAuthCode:', err);
        await bot.telegram.sendMessage(chatId, 
            '❌ <b>Gagal Menyimpan Akun:</b>\n<code>' + escapeHtml(err.message) + '</code>',
            { parse_mode: 'HTML' }
        );
    }
}

// ─── File Upload Handler ──────────────────────────────────────────────────────

const uploadedFiles = new Map();

async function downloadTelegramFile(ctx, fileId, preferredName) {
    const link = await ctx.telegram.getFileLink(fileId);
    const fileName = preferredName || ('file_' + Date.now());
    const sanitizedName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const destPath = path.join(UPLOADS_DIR, sanitizedName);

    const res = await fetch(link.href);
    if (!res.ok) throw new Error('Gagal mendownload file dari Telegram');
    const buffer = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(destPath, buffer);

    return {
        filePath: destPath,
        fileName: sanitizedName,
        fileSize: buffer.length
    };
}

// ─── Complete Session Management ──────────────────────────────────────────────

function getAllSessions() {
    try {
        const list = store.getAgySessions(AGY_DB_PATH);
        const aliases = loadAliases();
        const reverseAliases = {};
        for (const [k, v] of Object.entries(aliases)) {
            reverseAliases[v] = k;
        }

        return list.map(item => {
            let formattedTime = '';
            if (item.time) {
                try {
                    const d = new Date(item.time);
                    if (isNaN(d.getTime())) throw new Error('invalid date');
                    formattedTime = d.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' WIB';
                } catch (_) {
                    formattedTime = item.time.substring(0, 16).replace('T', ' ');
                }
            }
            return {
                id: item.id,
                title: item.title || 'Sesi Tanpa Judul',
                steps: item.steps || 0,
                time: item.time,
                timeFormatted: formattedTime,
                alias: reverseAliases[item.id] || null
            };
        });
    } catch (e) {
        console.error('Error in getAllSessions:', e);
        return [];
    }
}

function renderSessionsView(page = 1, activeConvoId = null) {
    const list = getAllSessions();
    const PER_PAGE = 4;
    const totalPages = Math.ceil(list.length / PER_PAGE) || 1;
    const curPage = Math.min(Math.max(1, page), totalPages);
    const startIdx = (curPage - 1) * PER_PAGE;
    const pageItems = list.slice(startIdx, startIdx + PER_PAGE);

    let text = `📂 <b>Daftar Riwayat Sesi Percakapan</b> (Halaman ${curPage}/${totalPages})\n`;
    text += `Total Sesi Tersimpan: <b>${list.length} sesi</b>\n`;
    text += `☁️ <b>Cadangan GitHub:</b> <a href="${BACKUP_REPO_URL}">buka repositori</a>\n`;
    text += `───────────────\n\n`;

    const buttons = [];
    pageItems.forEach((s, idx) => {
        const num = startIdx + idx + 1;
        const isActive = activeConvoId === s.id;
        const badge = isActive ? '🟢 <b>[SEDANG AKTIF]</b>\n' : '';
        const aliasTag = s.alias ? `🏷️ <code>${escapeHtml(s.alias)}</code> • ` : '';

        text += `${badge}<b>#${num} 📌 ${escapeHtml(s.title)}</b>\n`;
        text += `${aliasTag}🆔 <code>${s.id}</code>\n`;
        text += `💬 ${s.steps} interaksi | 🕒 ${s.timeFormatted}\n\n`;

        if (!isActive) {
            buttons.push([Markup.button.callback(`▶️ Pakai Sesi #${num} (${s.title.substring(0, 20)})`, `load_session_${s.id}`)]);
        }
    });

    // Pagination row
    const navRow = [];
    if (curPage > 1) {
        navRow.push(Markup.button.callback('◀️ Sebelumnya', `sessions_page_${curPage - 1}`));
    }
    if (curPage < totalPages) {
        navRow.push(Markup.button.callback('Berikutnya ▶️', `sessions_page_${curPage + 1}`));
    }
    if (navRow.length > 0) buttons.push(navRow);

    // Controls row
    buttons.push([
        Markup.button.callback('✏️ Masukkan ID / Nama Sesi', 'btn_input_session'),
        Markup.button.callback('➕ Sesi Baru (/new)', 'btn_new_session')
    ]);
    buttons.push([
        Markup.button.url('☁️ Lihat Cadangan di GitHub', BACKUP_REPO_URL),
        Markup.button.callback('🔄 Cadangkan Sekarang', 'btn_backup_now')
    ]);

    return { text, keyboard: Markup.inlineKeyboard(buttons) };
}

// ─── Telegraf Bot ─────────────────────────────────────────────────────────────

const bot = new Telegraf(BOT_TOKEN);
const userSessions = new Map();

const PERSISTED_KEYS = new Set(['model', 'mode', 'conversationId', 'pendingAlias']);

// State sesi per chat disimpan di SQLite: setiap perubahan model/mode/sesi langsung
// tersimpan, jadi tidak hilang saat bot restart (PM2 restart, deploy, crash).
function getSession(chatId) {
    const key = String(chatId);
    if (!userSessions.has(key)) {
        const saved = store.getChatSettings(key, { model: DEFAULT_MODEL, mode: DEFAULT_MODE });
        const state = {
            ...saved,
            waitingForSessionInput: false,
            currentProcess: null,
        };
        userSessions.set(key, new Proxy(state, {
            set(target, prop, value) {
                target[prop] = value;
                if (PERSISTED_KEYS.has(prop)) {
                    try { store.saveChatSettings(key, target); }
                    catch (e) { console.error('[db] Gagal menyimpan pengaturan chat:', e.message); }
                }
                return true;
            }
        }));
    }
    return userSessions.get(key);
}

// Auth Middleware
bot.use((ctx, next) => {
    const chatId = ctx.chat?.id ? String(ctx.chat.id) : null;
    if (!chatId) return;
    if (ALLOWED_CHAT_IDS.length > 0 && !ALLOWED_CHAT_IDS.includes(chatId)) {
        console.warn('[auth] Unauthorized chatId: ' + chatId);
        return ctx.reply('⛔ Akses ditolak. Chat ID Anda tidak diizinkan.');
    }
    return next();
});

function escapeHtml(text) {
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ─── Execution Logic ──────────────────────────────────────────────────────────

async function executeAgyPrompt(ctx, userText, attachedFile = null) {
    const session = getSession(ctx.chat.id);
    if (session.currentProcess) {
        return ctx.reply('⚠️ Agen sedang mengerjakan tugas sebelumnya. Ketik /stop jika ingin membatalkannya.');
    }

    const startedAt = Date.now();
    const chatId = ctx.chat.id;
    const modelUsed = session.model;
    const { id: accountId, account: activeAccount } = getActiveAccount();

    const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    let frameIdx = 0;
    const renderProgress = () =>
        `${frames[frameIdx++ % frames.length]} <b>Antigravity sedang bekerja…</b>\n` +
        `⚡ <code>${escapeHtml(modelUsed)}</code> • ⏱ ${formatDuration(Date.now() - startedAt)}\n` +
        `<i>Ketik /stop untuk membatalkan.</i>`;

    const waitMsg = await ctx.reply(renderProgress(), { parse_mode: 'HTML' });

    // Pesan status hidup: diperbarui tiap 4 detik + indikator "sedang mengetik"
    const progressTimer = setInterval(() => {
        ctx.telegram.editMessageText(chatId, waitMsg.message_id, undefined, renderProgress(), { parse_mode: 'HTML' }).catch(() => {});
        ctx.telegram.sendChatAction(chatId, 'typing').catch(() => {});
    }, 4000);
    ctx.telegram.sendChatAction(chatId, 'typing').catch(() => {});

    let promptText = userText;
    if (attachedFile) {
        const isZip = attachedFile.fileName.endsWith('.zip') || attachedFile.fileName.endsWith('.tar.gz');
        promptText = `[Instruksi User]:\n${userText}\n\n` +
            `[Lampiran File]:\n` +
            `- Lokasi file di VPS: "${attachedFile.filePath}"\n` +
            `- Nama file: "${attachedFile.fileName}"\n` +
            `- Ukuran: ${attachedFile.fileSize} bytes\n` +
            (isZip ? `- Tipe arsip: File merupakan arsip zip/tar.gz. Anda dapat memeriksa atau mengekstrak isinya.\n` : '') +
            `\nSilakan baca, analisis, dan proses file di path tersebut sesuai permintaan user di atas.`;
    }

    if (!session.conversationId && !promptText.startsWith('[Konteks Runtime:')) {
        promptText = `[Konteks Runtime: Anda adalah AI Agent untuk Telegram Bot (Antigravity CLI Bot). Konfigurasi bot telah diset di .env. Output Anda dikirim langsung ke pengguna Telegram, jadi tulis jawaban dalam Markdown yang rapi dan ringkas (judul pendek, poin-poin, blok kode dengan nama bahasa; hindari tabel lebar).]\n\n` + promptText;
    }

    const args = [
        '--dangerously-skip-permissions',
        '--model', modelUsed,
    ];

    if (session.mode && session.mode !== 'auto') {
        args.push('--mode', session.mode);
    }

    if (session.conversationId) {
        args.push('--conversation', session.conversationId);
    }

    args.push('--print', promptText);

    console.log('[bot] Executing agy model=' + modelUsed + ' convo=' + (session.conversationId || 'new') + ' file=' + (attachedFile ? attachedFile.fileName : 'none'));

    let stdoutData = '';
    let stderrData = '';

    const child = spawn(AGY_PATH, args, {
        cwd: WORKSPACE_DIR,
        env: {
            ...process.env,
            HOME: '/root',
            PATH: '/usr/local/bin:/root/.local/bin:' + process.env.PATH,
            AI_AGENT_PLATFORM: 'telegram',
            TELEGRAM_BOT_ACTIVE: 'true',
            TELEGRAM_CHAT_ID: String(chatId),
            BACKUP_REPO_URL: BACKUP_REPO_URL,
        }
    });

    session.currentProcess = child;

    const finishProgress = async () => {
        clearInterval(progressTimer);
        session.currentProcess = null;
        await ctx.telegram.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
    };

    child.stdout.on('data', (d) => {
        stdoutData += d.toString();
    });

    child.stderr.on('data', (d) => {
        stderrData += d.toString();
    });

    child.on('close', async (code, signal) => {
        await finishProgress();

        // Dibatalkan lewat /stop: pesan konfirmasi sudah dikirim oleh handler /stop
        if (signal) return;

        if (code !== 0) {
            console.error('[bot] agy exited with code ' + code + '. Stderr: ' + stderrData);
            const errPreview = cleanCliOutput(stderrData) || cleanCliOutput(stdoutData) || ('Process exited with code ' + code);
            return await ctx.reply(
                '❌ <b>Terjadi kesalahan saat memproses</b>\n\n' +
                '<pre>' + escapeHtml(errPreview.substring(0, 3000)) + '</pre>\n' +
                '<i>Coba kirim ulang, ganti akun lewat /accounts, atau mulai sesi baru dengan /new.</i>',
                { parse_mode: 'HTML' }
            );
        }

        // Save conversation ID
        try {
            const cachePath = '/root/.gemini/antigravity-cli/cache/last_conversations.json';
            if (fs.existsSync(cachePath)) {
                const cache = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
                if (cache[WORKSPACE_DIR]) {
                    const newId = cache[WORKSPACE_DIR];
                    session.conversationId = newId;
                    if (session.pendingAlias) {
                        saveAlias(session.pendingAlias, newId);
                        session.pendingAlias = null;
                    }
                }
            }
        } catch (e) {
            console.warn('[bot] Could not update conversation cache:', e.message);
        }

        const durationMs = Date.now() - startedAt;
        const replyText = cleanCliOutput(stdoutData);

        // Catat percakapan ke SQLite
        try {
            store.addMessage({
                chatId,
                conversationId: session.conversationId,
                role: 'user',
                content: userText + (attachedFile ? `\n📎 ${attachedFile.fileName}` : ''),
                model: modelUsed,
                accountId,
            });
            store.addMessage({
                chatId,
                conversationId: session.conversationId,
                role: 'assistant',
                content: replyText || '(tugas selesai tanpa output teks)',
                model: modelUsed,
                accountId,
                durationMs,
            });
        } catch (e) {
            console.warn('[db] Gagal mencatat percakapan:', e.message);
        }

        const footer = buildFooter({ model: modelUsed, durationMs, email: activeAccount && activeAccount.email });

        if (!replyText) {
            triggerSessionBackup();
            return await ctx.reply('✅ <b>Tugas selesai dieksekusi.</b>\n\n' + footer, { parse_mode: 'HTML' });
        }

        await sendFormattedLongMessage(ctx, replyText, footer);
        triggerSessionBackup();
    });

    child.on('error', async (err) => {
        await finishProgress();
        console.error('[bot] Failed to spawn agy:', err);
        await ctx.reply('❌ <b>Gagal menjalankan agy CLI:</b>\n<code>' + escapeHtml(err.message) + '</code>', { parse_mode: 'HTML' });
    });
}

// ─── Bot Commands ─────────────────────────────────────────────────────────────

bot.command('start', async (ctx) => {
    const { id, account } = getActiveAccount();
    const session = getSession(ctx.chat.id);
    const welcome = 
        '👋 <b>Selamat datang di Antigravity CLI Telegram Bot!</b>\n\n' +
        '🟢 <b>Akun Aktif:</b> ' + (account ? '<code>' + escapeHtml(account.email) + '</code> (#' + id + ')' : '<i>Belum ada</i>') + '\n' +
        '⚡ <b>Model:</b> <code>' + session.model + '</code>\n' +
        '🛠️ <b>Mode:</b> <code>' + session.mode + '</code>\n' +
        '💬 <b>Sesi Aktif:</b> ' + (session.conversationId ? '<code>' + session.conversationId + '</code>' : '<i>Sesi Baru (Konteks Fresh)</i>') + '\n\n' +
        '<b>Daftar Perintah:</b>\n' +
        '• <b>/sessions</b> - Lihat daftar lengkap riwayat sesi obrolan\n' +
        '• <b>/session &lt;id/nama&gt;</b> - Masukkan / ganti ID sesi sendiri\n' +
        '• <b>/history</b> - Lihat riwayat pesan sesi ini\n' +
        '• <b>/export</b> - Unduh riwayat sesi sebagai file .md\n' +
        '• <b>/backup</b> - Cadangkan riwayat percakapan ke repo GitHub\n' +
        '• <b>/new</b> - Mulai sesi baru (reset riwayat obrolan)\n' +
        '• <b>/accounts</b> - Kelola & switch akun Google AI Pro\n' +
        '• <b>/login</b> - Tambah akun Google baru via OAuth\n' +
        '• <b>/model</b> - Ganti model AI (Gemini, Claude, GPT)\n' +
        '• <b>/mode</b> - Ganti mode eksekusi (accept-edits, plan)\n' +
        '• <b>/screenshot &lt;url&gt;</b> - Ambil tangkapan layar website\n' +
        '• <b>/stop</b> - Hentikan tugas CLI yang sedang berjalan\n' +
        '• <b>/status</b> - Cek resource server & akun aktif\n\n' +
        '💡 <i>Kirim pesan apa saja langsung, atau upload file lalu reply pesan file tersebut untuk dianalisis!</i>';

    await ctx.reply(welcome, { parse_mode: 'HTML', reply_markup: { remove_keyboard: true } });
});

bot.command('help', (ctx) => ctx.reply(
    '📖 <b>Panduan Lengkap Penggunaan Bot:</b>\n\n' +
    '1. <b>Kirim Pesan & Coding:</b>\n' +
    'Langsung ketik prompt atau instruksi coding apa saja. Output otomatis diformat indah & rapi.\n\n' +
    '2. <b>Upload Dokumen, Gambar, atau Zip:</b>\n' +
    'Kirim file ke bot, lalu balas (reply) file tersebut dengan instruksi Anda, atau isi langsung di keterangan (caption).\n\n' +
    '3. <b>Kontrol & Custom Session ID:</b>\n' +
    '• <b>/sessions:</b> Lihat semua riwayat sesi obrolan secara lengkap dengan tombol beralih cepat.\n' +
    '• <b>/session &lt;id_atau_nama&gt;:</b> Masukkan Session ID atau beri nama sesi kustom Anda sendiri!\n' +
    '• <b>/history:</b> Lihat pesan terakhir di sesi aktif (disimpan di SQLite).\n' +
    '• <b>/export:</b> Unduh seluruh riwayat sesi aktif sebagai file .md.\n' +
    '• <b>/backup:</b> Cek status & sinkronkan database percakapan ke GitHub.\n' +
    '• <b>/new:</b> Mulai percakapan dari awal.\n\n' +
    '4. <b>Akun & Model:</b>\n' +
    '• <b>/accounts:</b> Ganti akun Google AI Pro aktif.\n' +
    '• <b>/login:</b> Tambah akun baru via Google OAuth.\n' +
    '• <b>/model:</b> Pilih model AI.\n' +
    '• <b>/screenshot &lt;url&gt;:</b> Screenshot halaman website.',
    { parse_mode: 'HTML', reply_markup: { remove_keyboard: true } }
));

// ─── SESSIONS MANAGEMENT (/sessions & /session) ───────────────────────────────

bot.command('sessions', async (ctx) => {
    const session = getSession(ctx.chat.id);
    const { text, keyboard } = renderSessionsView(1, session.conversationId);
    await ctx.reply(text, { parse_mode: 'HTML', ...keyboard });
});

bot.command('backup', async (ctx) => {
    triggerSessionBackup();
    await ctx.reply(
        `☁️ <b>Cadangan Sesi Antigravity AI</b>\n\n` +
        `Setiap bot selesai membalas pesan, database sesi otomatis diperbarui & di-push ke GitHub.\n\n` +
        `🔗 <b>Repository Cadangan:</b>\n` +
        `<a href="${BACKUP_REPO_URL}">${escapeHtml(BACKUP_REPO_URL)}</a>\n\n` +
        `<i>Sinkronisasi manual ke GitHub sedang berjalan di background...</i>`,
        { parse_mode: 'HTML' }
    );
});

bot.action('btn_backup_now', async (ctx) => {
    await ctx.answerCbQuery('Menjalankan sinkronisasi cadangan ke GitHub...');
    triggerSessionBackup();
    await ctx.reply(
        `☁️ <b>Pencadangan Sesi Dijalankan!</b>\n\n` +
        `Data percakapan, transkrip, dan artefak sedang disinkronkan ke repo:\n` +
        `<a href="${BACKUP_REPO_URL}">${escapeHtml(BACKUP_REPO_URL)}</a>`,
        { parse_mode: 'HTML' }
    );
});

bot.action(/sessions_page_(\d+)/, async (ctx) => {
    const page = parseInt(ctx.match[1], 10) || 1;
    const session = getSession(ctx.chat.id);
    const { text, keyboard } = renderSessionsView(page, session.conversationId);
    await ctx.answerCbQuery();
    await ctx.editMessageText(text, { parse_mode: 'HTML', ...keyboard });
});

bot.action(/load_session_(.+)/, async (ctx) => {
    const convoId = ctx.match[1];
    const session = getSession(ctx.chat.id);
    session.conversationId = convoId;
    session.pendingAlias = null;
    await ctx.answerCbQuery('Sesi berhasil diaktifkan!');

    const list = getAllSessions();
    const found = list.find(x => x.id === convoId);
    const title = found ? found.title : 'Sesi Terpilih';

    await ctx.editMessageText(
        `✅ <b>Berhasil Beralih ke Sesi:</b>\n\n` +
        `📌 <b>Judul:</b> ${escapeHtml(title)}\n` +
        `🆔 <b>ID:</b> <code>${convoId}</code>\n\n` +
        `Konteks obrolan lama dimuat kembali. Pesan Anda berikutnya akan melanjutkan sesi ini.`,
        { parse_mode: 'HTML' }
    );
});

bot.action('btn_input_session', async (ctx) => {
    const session = getSession(ctx.chat.id);
    session.waitingForSessionInput = true;
    await ctx.answerCbQuery();
    await ctx.reply(
        '✍️ <b>Masukkan Session ID atau Nama Sesi Anda:</b>\n\n' +
        'Silakan ketik atau paste:\n' +
        '• <b>UUID Sesi Lama:</b> (misal: <code>0315447a-a95b-4406-a9f2-c6da468bcb20</code>)\n' +
        '• <b>Nama / Alias Sesi Kustom:</b> (misal: <code>projek-alpha</code> atau <code>furina</code>)\n\n' +
        '<i>Ketik langsung di chat balasan ini...</i>',
        { parse_mode: 'HTML' }
    );
});

bot.action('btn_new_session', async (ctx) => {
    const session = getSession(ctx.chat.id);
    session.conversationId = null;
    session.pendingAlias = null;
    await ctx.answerCbQuery('Sesi baru dimulai!');
    await ctx.editMessageText('🔄 <b>Sesi baru telah dimulai.</b> Konteks percakapan direset dari awal.', { parse_mode: 'HTML' });
});

bot.command('session', async (ctx) => {
    const raw = ctx.message.text.replace(/^\/session(@\w+)?/i, '').trim();
    const session = getSession(ctx.chat.id);

    if (!raw) {
        return ctx.reply(
            `💬 <b>Sesi Aktif Saat Ini:</b>\n` +
            `<code>${session.conversationId || 'Belum ada (Sesi Baru)'}</code>\n\n` +
            `Gunakan format:\n<code>/session &lt;id_atau_nama_kustom&gt;</code>\n\n` +
            `Contoh:\n` +
            `• <code>/session 0315447a-a95b-4406-a9f2-c6da468bcb20</code>\n` +
            `• <code>/session projek-website</code>`,
            { parse_mode: 'HTML' }
        );
    }

    await applyCustomSession(ctx, raw);
});

async function applyCustomSession(ctx, input) {
    const session = getSession(ctx.chat.id);
    session.waitingForSessionInput = false;
    const target = input.trim();
    const aliases = loadAliases();

    // 1. Check if input matches known alias
    if (aliases[target.toLowerCase()]) {
        const convoId = aliases[target.toLowerCase()];
        session.conversationId = convoId;
        session.pendingAlias = target.toLowerCase();
        return await ctx.reply(
            `✅ <b>Berhasil Beralih ke Sesi [${escapeHtml(target)}]!</b>\n\n` +
            `🆔 <b>ID Sesi:</b> <code>${convoId}</code>\n\n` +
            `Percakapan selanjutnya akan melanjutkan konteks sesi ini.`,
            { parse_mode: 'HTML' }
        );
    }

    // 2. Check if input is a valid UUID of existing conversation
    const all = getAllSessions();
    const found = all.find(s => s.id === target || s.id.startsWith(target));

    if (found) {
        session.conversationId = found.id;
        session.pendingAlias = null;
        return await ctx.reply(
            `✅ <b>Berhasil Memuat Sesi Terdaftar:</b>\n\n` +
            `📌 <b>Judul:</b> ${escapeHtml(found.title)}\n` +
            `🆔 <b>ID Sesi:</b> <code>${found.id}</code>\n` +
            `💬 ${found.steps} interaksi sebelumnya.\n\n` +
            `Percakapan selanjutnya akan melanjutkan konteks sesi ini!`,
            { parse_mode: 'HTML' }
        );
    }

    // 3. It is a new custom Session Name/ID created by the user!
    session.conversationId = null;
    session.pendingAlias = target;
    return await ctx.reply(
        `🆕 <b>Sesi Kustom Disiapkan: "${escapeHtml(target)}"</b>\n\n` +
        `Sesi baru dengan nama ini telah diaktifkan. Silakan langsung kirim pesan atau instruksi pertama Anda! ID sesi akan otomatis dihubungkan dengan nama ini.`,
        { parse_mode: 'HTML' }
    );
}

// ─── SCREENSHOT FEATURE (/screenshot <url>) ───────────────────────────────────

bot.command('screenshot', async (ctx) => {
    const raw = ctx.message.text.replace(/^\/screenshot(@\w+)?/i, '').trim();
    if (!raw) {
        return ctx.reply(
            '📸 <b>Fitur Screenshot Web:</b>\n\n' +
            'Gunakan format:\n<code>/screenshot &lt;url&gt;</code>\n\n' +
            'Contoh:\n<code>/screenshot https://google.com</code>\n<code>/screenshot https://github.com</code>',
            { parse_mode: 'HTML' }
        );
    }

    let targetUrl = raw;
    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
        targetUrl = 'https://' + targetUrl;
    }

    const waitMsg = await ctx.reply('📸 <i>Mengambil tangkapan layar dari: ' + escapeHtml(targetUrl) + '...</i>', { parse_mode: 'HTML' });

    let browser = null;
    const shotPath = path.join('/tmp', `shot_${Date.now()}.png`);

    try {
        browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
        });
        const page = await browser.newPage();
        await page.setViewport({ width: 1280, height: 800 });
        await page.goto(targetUrl, { waitUntil: 'networkidle2', timeout: 25000 });
        await page.screenshot({ path: shotPath, fullPage: false });
        await browser.close();
        browser = null;

        await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
        await ctx.replyWithPhoto({ source: shotPath }, {
            caption: `📸 <b>Screenshot Web:</b> <code>${escapeHtml(targetUrl)}</code>`,
            parse_mode: 'HTML'
        });

        try { fs.unlinkSync(shotPath); } catch (_) {}
    } catch (err) {
        if (browser) try { await browser.close(); } catch (_) {}
        try { await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (_) {}
        try { fs.unlinkSync(shotPath); } catch (_) {}
        console.error('Screenshot error:', err);
        await ctx.reply('❌ <b>Gagal mengambil screenshot:</b>\n<code>' + escapeHtml(err.message) + '</code>', { parse_mode: 'HTML' });
    }
});

// ─── Accounts Management ──────────────────────────────────────────────────────

bot.command('accounts', async (ctx) => {
    const data = loadAccountsData();
    const accounts = data.accounts || {};
    const keys = Object.keys(accounts);

    if (keys.length === 0) {
        return ctx.reply('⚠️ Belum ada akun Google tersimpan. Gunakan /login untuk menambahkan.', { parse_mode: 'HTML' });
    }

    let text = '👥 <b>Daftar Akun Antigravity Tersimpan:</b>\n\n';
    const buttons = [];

    for (const key of keys) {
        const acc = accounts[key];
        const isActive = String(key) === String(data.activeId);
        const statusIcon = isActive ? '🟢 <b>[AKTIF]</b>' : '⚪';
        text += `${statusIcon} <b>Akun #${key}:</b> <code>${escapeHtml(acc.email)}</code>\n`;
        if (acc.name) text += `   👤 Nama: ${escapeHtml(acc.name)}\n`;

        if (!isActive) {
            buttons.push([Markup.button.callback(`🔄 Pakai Akun #${key} (${acc.email.split('@')[0]})`, `switch_acc_${key}`)]);
        }
    }

    buttons.push([Markup.button.callback('➕ Tambah Akun Baru', 'btn_add_account')]);

    await ctx.reply(text, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard(buttons)
    });
});

bot.action(/switch_acc_(\w+)/, async (ctx) => {
    const targetId = ctx.match[1];
    await ctx.answerCbQuery('Mengaktifkan akun #' + targetId + '...');
    try {
        const acc = await activateAccount(targetId);
        const session = getSession(ctx.chat.id);
        session.conversationId = null;
        await ctx.editMessageText(
            '✅ <b>Akun Berhasil Diganti!</b>\n\n' +
            '🟢 Akun aktif sekarang: <code>' + escapeHtml(acc.email) + '</code> (#' + targetId + ')\n' +
            'Konteks percakapan direset otomatis untuk akun ini.',
            { parse_mode: 'HTML' }
        );
    } catch (e) {
        await ctx.reply('❌ Gagal mengganti akun: ' + e.message);
    }
});

bot.action('btn_add_account', async (ctx) => {
    await ctx.answerCbQuery();
    await handleLoginCommand(ctx);
});

async function handleLoginCommand(ctx) {
    const waitMsg = await ctx.reply('⏳ Menyiapkan sesi Google OAuth...');
    try {
        const { authUrl } = await startOAuthFlow(ctx.chat.id);
        await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});

        const msg = 
            '🔐 <b>Tambah Akun Google Antigravity:</b>\n\n' +
            '1. Klik tombol <b>"Masuk dengan Google"</b> di bawah.\n' +
            '2. Login dengan akun Google Anda dan izinkan akses.\n' +
            '3. Saat browser dialihkan ke halaman <code>localhost:8888...</code>, <b>Copy seluruh alamat URL</b> di browser Anda.\n' +
            '4. <b>Kirim (paste) URL tersebut ke chat bot ini.</b>';

        await ctx.reply(msg, {
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([
                [Markup.button.url('🔒 Masuk dengan Google', authUrl)]
            ])
        });
    } catch (err) {
        await ctx.reply('❌ Gagal membuat URL OAuth: ' + err.message);
    }
}

bot.command('login', handleLoginCommand);
bot.command('add_account', handleLoginCommand);

bot.command('model', async (ctx) => {
    const session = getSession(ctx.chat.id);
    const models = [
        { id: 'gemini-3.8-flash-high', label: '⚡ Gemini 3.8 Flash High (Fast)' },
        { id: 'gemini-3.8-flash-medium', label: '🌟 Gemini 3.8 Flash Medium' },
        { id: 'claude-sonnet-4-6', label: '🧠 Claude Sonnet 4.6 (Thinking)' },
        { id: 'claude-opus-4-6-thinking', label: '👑 Claude Opus 4.6 Thinking' },
        { id: 'gpt-oss-120b-medium', label: '🤖 GPT-OSS 120B' },
    ];

    const keyboard = models.map(m => {
        const isCur = session.model === m.id;
        return [Markup.button.callback((isCur ? '✅ ' : '') + m.label, 'set_model_' + m.id)];
    });

    await ctx.reply(
        '🎯 <b>Pilih Model AI:</b>\n\nModel saat ini: <code>' + session.model + '</code>',
        { parse_mode: 'HTML', ...Markup.inlineKeyboard(keyboard) }
    );
});

bot.action(/set_model_(.+)/, async (ctx) => {
    const modelId = ctx.match[1];
    const session = getSession(ctx.chat.id);
    session.model = modelId;
    await ctx.answerCbQuery('Model diubah ke ' + modelId);
    await ctx.editMessageText('✅ Model aktif sekarang: <code>' + modelId + '</code>', { parse_mode: 'HTML' });
});

bot.command('mode', async (ctx) => {
    const session = getSession(ctx.chat.id);
    const modes = [
        { id: 'accept-edits', label: '⚡ Accept-Edits (Langsung Eksekusi & Buat File)' },
        { id: 'plan', label: '📋 Plan (Perencanaan Langkah Demi Langkah)' },
    ];

    const keyboard = modes.map(m => {
        const isCur = session.mode === m.id;
        return [Markup.button.callback((isCur ? '✅ ' : '') + m.label, 'set_mode_' + m.id)];
    });

    await ctx.reply(
        '⚙️ <b>Pilih Mode Eksekusi:</b>\n\nMode saat ini: <code>' + session.mode + '</code>',
        { parse_mode: 'HTML', ...Markup.inlineKeyboard(keyboard) }
    );
});

bot.action(/set_mode_(.+)/, async (ctx) => {
    const modeId = ctx.match[1];
    const session = getSession(ctx.chat.id);
    session.mode = modeId;
    await ctx.answerCbQuery('Mode diubah ke ' + modeId);
    await ctx.editMessageText('✅ Mode aktif sekarang: <code>' + modeId + '</code>', { parse_mode: 'HTML' });
});

bot.command('new', (ctx) => {
    const session = getSession(ctx.chat.id);
    session.conversationId = null;
    session.pendingAlias = null;
    ctx.reply('🔄 <b>Sesi percakapan baru telah dimulai.</b> Konteks lama direset.', { parse_mode: 'HTML' });
});

bot.command('stop', (ctx) => {
    const session = getSession(ctx.chat.id);
    if (session.currentProcess) {
        try {
            session.currentProcess.kill('SIGTERM');
            session.currentProcess = null;
            return ctx.reply('🛑 Perintah eksekusi agy telah dibatalkan.');
        } catch (e) {
            return ctx.reply('⚠️ Gagal menghentikan proses: ' + e.message);
        }
    }
    ctx.reply('ℹ️ Tidak ada proses agy yang sedang berjalan.');
});

bot.command('status', (ctx) => {
    const session = getSession(ctx.chat.id);
    const { id, account } = getActiveAccount();
    const mem = process.memoryUsage();
    const ramMB = (mem.rss / 1024 / 1024).toFixed(1);
    const dbi = store.dbInfo();

    const txt = 
        '📊 <b>Status Sistem Antigravity CLI:</b>\n\n' +
        '🟢 <b>Akun Aktif:</b> ' + (account ? '<code>' + escapeHtml(account.email) + '</code> (#' + id + ')' : '<i>Belum ada</i>') + '\n' +
        '⚡ <b>Model:</b> <code>' + session.model + '</code>\n' +
        '🛠️ <b>Mode:</b> <code>' + session.mode + '</code>\n' +
        '💬 <b>Sesi Aktif:</b> ' + (session.conversationId ? '<code>' + session.conversationId + '</code>' : '<i>Sesi Baru (Fresh)</i>') + '\n' +
        '📁 <b>Workspace:</b> <code>' + WORKSPACE_DIR + '</code>\n' +
        '💾 <b>Bot RAM:</b> ' + ramMB + ' MB\n' +
        '🗄️ <b>Database:</b> SQLite • ' + dbi.messages + ' pesan • ' + (dbi.sizeBytes / 1024).toFixed(1) + ' KB\n' +
        '⚙️ <b>Binary CLI:</b> <code>/usr/local/bin/agy (v1.5.0)</code>';

    ctx.reply(txt, { parse_mode: 'HTML' });
});

// ─── RIWAYAT PERCAKAPAN (SQLite): /history & /export ─────────────────────────

function fmtTime(ts) {
    return new Date(ts * 1000).toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
    });
}

bot.command('history', async (ctx) => {
    const session = getSession(ctx.chat.id);
    if (!session.conversationId) {
        return ctx.reply('ℹ️ Belum ada sesi aktif. Kirim pesan dulu atau pilih sesi lewat /sessions.');
    }

    const arg = parseInt(ctx.message.text.split(/\s+/)[1], 10);
    const n = Math.min(Math.max(arg || 6, 1), 12);
    const rows = store.getMessages(session.conversationId, n);
    if (!rows.length) {
        return ctx.reply('📭 Belum ada riwayat tercatat untuk sesi ini. Riwayat dicatat mulai pesan berikutnya.');
    }

    const total = store.countMessages(session.conversationId);
    let text = `🕘 <b>Riwayat Sesi</b> • ${rows.length} dari ${total} pesan terakhir\n` +
        `🆔 <code>${session.conversationId}</code>\n───────────────\n\n`;
    for (const r of rows) {
        const who = r.role === 'user' ? '🙋 <b>Kamu</b>' : '🤖 <b>AI</b>';
        let body = r.content.replace(/\s+/g, ' ').trim();
        if (body.length > 220) body = body.slice(0, 220) + '…';
        text += `${who} <i>• ${fmtTime(r.created_at)}</i>\n${escapeHtml(body)}\n\n`;
    }
    text += '<i>Gunakan /export untuk mengunduh seluruh riwayat sesi ini.</i>';
    await ctx.reply(text, { parse_mode: 'HTML' });
});

bot.command('export', async (ctx) => {
    const session = getSession(ctx.chat.id);
    if (!session.conversationId) {
        return ctx.reply('ℹ️ Belum ada sesi aktif untuk diekspor.');
    }
    const rows = store.getMessages(session.conversationId, 100000);
    if (!rows.length) {
        return ctx.reply('📭 Belum ada riwayat tercatat untuk sesi ini.');
    }

    let md = `# Riwayat Sesi Antigravity\n\n- ID sesi: \`${session.conversationId}\`\n- Jumlah pesan: ${rows.length}\n\n---\n\n`;
    for (const r of rows) {
        const who = r.role === 'user' ? '🙋 Kamu' : '🤖 AI';
        const meta = [fmtTime(r.created_at), r.model, r.duration_ms != null ? formatDuration(r.duration_ms) : null]
            .filter(Boolean).join(' • ');
        md += `## ${who}  \n*${meta}*\n\n${r.content}\n\n---\n\n`;
    }

    await ctx.replyWithDocument(
        { source: Buffer.from(md, 'utf8'), filename: `sesi-${session.conversationId.slice(0, 8)}.md` },
        { caption: `📤 Riwayat sesi (${rows.length} pesan)` }
    );
});

// ─── Media & Upload Listener ──────────────────────────────────────────────────

bot.on(['document', 'photo', 'video', 'audio'], async (ctx) => {
    try {
        let fileId = null;
        let preferredName = null;

        if (ctx.message.document) {
            fileId = ctx.message.document.file_id;
            preferredName = ctx.message.document.file_name;
        } else if (ctx.message.photo) {
            const p = ctx.message.photo[ctx.message.photo.length - 1];
            fileId = p.file_id;
            preferredName = 'photo_' + Date.now() + '.jpg';
        } else if (ctx.message.video) {
            fileId = ctx.message.video.file_id;
            preferredName = ctx.message.video.file_name || ('video_' + Date.now() + '.mp4');
        } else if (ctx.message.audio) {
            fileId = ctx.message.audio.file_id;
            preferredName = ctx.message.audio.file_name || ('audio_' + Date.now() + '.mp3');
        }

        if (!fileId) return;

        const waitMsg = await ctx.reply('⏳ <i>Mengunduh dan menyimpan lampiran ke workspace VPS...</i>', { parse_mode: 'HTML' });
        const saved = await downloadTelegramFile(ctx, fileId, preferredName);
        uploadedFiles.set(ctx.message.message_id, saved);
        try { await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (_) {}

        const caption = (ctx.message.caption || '').trim();
        if (caption) {
            await executeAgyPrompt(ctx, caption, saved);
        } else {
            const sizeKB = (saved.fileSize / 1024).toFixed(1);
            const isZip = saved.fileName.endsWith('.zip') || saved.fileName.endsWith('.tar.gz');
            const infoMsg = 
                '📥 <b>File Berhasil Diterima & Disimpan!</b>\n\n' +
                '📄 <b>Nama File:</b> <code>' + escapeHtml(saved.fileName) + '</code>\n' +
                '📦 <b>Ukuran:</b> ' + sizeKB + ' KB\n' +
                '📁 <b>Path VPS:</b> <code>' + saved.filePath + '</code>\n\n' +
                (isZip ? '<i>Catatan: File arsip zip/tar.gz terdeteksi. AI dapat memeriksa dan mengekstrak isinya.</i>\n\n' : '') +
                '💬 <b>Cara Instruksi:</b>\n' +
                '• <b>Balas (Reply)</b> pesan ini dan ketik apa yang ingin AI lakukan dengan file ini.\n' +
                '• Atau langsung ketik pertanyaan/perintah Anda.';

            await ctx.reply(infoMsg, { parse_mode: 'HTML' });
        }
    } catch (err) {
        console.error('Error handling media upload:', err);
        ctx.reply('❌ Gagal memproses file upload: ' + err.message);
    }
});

// ─── Text & Message Handler ───────────────────────────────────────────────────

bot.on('text', async (ctx) => {
    const text = ctx.message.text.trim();
    if (text.startsWith('/')) return;

    const session = getSession(ctx.chat.id);

    // If user was prompted to input Session ID / Name
    if (session.waitingForSessionInput) {
        return await applyCustomSession(ctx, text);
    }

    // Google OAuth code detection
    if (text.includes('code=') || (text.startsWith('4/') && text.length > 20)) {
        let code = '';
        try {
            if (text.startsWith('http')) {
                const u = new URL(text);
                code = u.searchParams.get('code');
            } else if (text.includes('code=')) {
                const match = text.match(/code=([^&\s]+)/);
                if (match) code = decodeURIComponent(match[1]);
            } else {
                code = text.split(/\s/)[0];
            }
        } catch (e) {
            console.error('Error parsing potential code:', e);
        }

        if (code) {
            const redirectUri = activeOAuthSession?.redirectUri || 'http://localhost:8888/oauth-callback';
            const waitMsg = await ctx.reply('⏳ <i>Menukarkan kode otorisasi Google...</i>', { parse_mode: 'HTML' });
            await handleAuthCode(code, redirectUri, ctx.chat.id);
            try { await ctx.telegram.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (_) {}
            return;
        }
    }

    // Reply-to-file detection
    let attachedFile = null;
    const replyMsg = ctx.message.reply_to_message;
    if (replyMsg) {
        if (uploadedFiles.has(replyMsg.message_id)) {
            attachedFile = uploadedFiles.get(replyMsg.message_id);
        } else if (replyMsg.document || replyMsg.photo || replyMsg.video || replyMsg.audio) {
            try {
                let fileId = null;
                let preferredName = null;
                if (replyMsg.document) {
                    fileId = replyMsg.document.file_id;
                    preferredName = replyMsg.document.file_name;
                } else if (replyMsg.photo) {
                    const p = replyMsg.photo[replyMsg.photo.length - 1];
                    fileId = p.file_id;
                    preferredName = 'photo_' + replyMsg.message_id + '.jpg';
                }
                if (fileId) {
                    const waitDl = await ctx.reply('⏳ <i>Mengunduh file yang Anda balas...</i>', { parse_mode: 'HTML' });
                    attachedFile = await downloadTelegramFile(ctx, fileId, preferredName);
                    uploadedFiles.set(replyMsg.message_id, attachedFile);
                    try { await ctx.telegram.deleteMessage(ctx.chat.id, waitDl.message_id); } catch (_) {}
                }
            } catch (e) {
                console.error('Error downloading replied file:', e);
            }
        }
    }

    await executeAgyPrompt(ctx, text, attachedFile);
});

// ─── Initial Startup ──────────────────────────────────────────────────────────

(async () => {
    try {
        const data = loadAccountsData();
        if (data.activeId && data.accounts[data.activeId]) {
            console.log('[init] Activating account #' + data.activeId + ' (' + data.accounts[data.activeId].email + ')');
            await activateAccount(data.activeId);
        }
    } catch (e) {
        console.warn('[init] Could not pre-activate account:', e.message);
    }

    const cleanCommands = [
        { command: 'start', description: 'Mulai bot & status sistem' },
        { command: 'help', description: 'Panduan penggunaan & fitur' },
        { command: 'sessions', description: 'Daftar lengkap riwayat sesi obrolan' },
        { command: 'session', description: 'Masukkan / ganti ID sesi sendiri' },
        { command: 'new', description: 'Mulai sesi baru (reset konteks)' },
        { command: 'history', description: 'Riwayat pesan sesi aktif' },
        { command: 'export', description: 'Unduh riwayat sesi (.md)' },
        { command: 'accounts', description: 'Kelola & switch akun Google' },
        { command: 'login', description: 'Tambah akun baru via Google OAuth' },
        { command: 'model', description: 'Pilih model AI (Gemini/Claude/GPT)' },
        { command: 'mode', description: 'Pilih mode eksekusi CLI' },
        { command: 'screenshot', description: 'Ambil screenshot website/halaman' },
        { command: 'stop', description: 'Hentikan proses yang sedang berjalan' },
        { command: 'status', description: 'Status server, memori & akun aktif' }
    ];

    try {
        const scopes = [
            { type: 'default' },
            { type: 'all_private_chats' }
        ];
        if (ALLOWED_CHAT_IDS[0]) {
            scopes.push({ type: 'chat', chat_id: ALLOWED_CHAT_IDS[0] });
        }

        for (const s of scopes) {
            for (const l of ['', 'en', 'id']) {
                const opt = { scope: s };
                if (l) opt.language_code = l;
                await bot.telegram.setMyCommands(cleanCommands, opt).catch(() => {});
            }
        }
        console.log('[init] All command scopes cleanly synchronized.');
    } catch (e) {
        console.warn('[init] Could not sync command menu:', e.message);
    }

    bot.launch().then(() => {
        console.log('✅ Antigravity CLI Telegram Bot is online and ready!');
    }).catch(err => {
        console.error('❌ Failed to launch bot:', err);
    });
})();

process.once('SIGINT', () => { bot.stop('SIGINT'); store.close(); });
process.once('SIGTERM', () => { bot.stop('SIGTERM'); store.close(); });
