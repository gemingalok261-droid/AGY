'use strict';
/**
 * db.js — Penyimpanan SQLite untuk Antigravity CLI Telegram Bot.
 *
 * Menggantikan:
 *   - session_aliases.json  -> tabel `aliases`
 *   - accounts.json         -> tabel `accounts` + `meta` (akun aktif)
 *   - state sesi di RAM     -> tabel `chat_settings` (tidak hilang saat bot restart)
 * Menambahkan:
 *   - tabel `messages`      -> riwayat percakapan bot (untuk /history & /export)
 *
 * Memakai modul bawaan Node.js `node:sqlite` (Node >= 22.5), jadi tanpa dependensi native.
 */

const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'bot.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
try { fs.chmodSync(DB_PATH, 0o600); } catch (_) {} // menyimpan refresh token -> batasi akses

db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS meta (
        key   TEXT PRIMARY KEY,
        value TEXT
    );

    CREATE TABLE IF NOT EXISTS chat_settings (
        chat_id         TEXT PRIMARY KEY,
        model           TEXT,
        mode            TEXT,
        conversation_id TEXT,
        pending_alias   TEXT,
        updated_at      INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS aliases (
        name            TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        created_at      INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS accounts (
        id               TEXT PRIMARY KEY,
        email            TEXT NOT NULL,
        name             TEXT,
        access_token     TEXT,
        refresh_token    TEXT,
        token_type       TEXT DEFAULT 'Bearer',
        expires_in       INTEGER,
        expiry_timestamp INTEGER,
        added_at         INTEGER,
        updated_at       INTEGER
    );

    CREATE TABLE IF NOT EXISTS messages (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id         TEXT NOT NULL,
        conversation_id TEXT,
        role            TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
        content         TEXT NOT NULL,
        model           TEXT,
        account_id      TEXT,
        duration_ms     INTEGER,
        created_at      INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_messages_convo ON messages (conversation_id, id);
    CREATE INDEX IF NOT EXISTS idx_messages_chat  ON messages (chat_id, id);
`);

const now = () => Math.floor(Date.now() / 1000);

let txDepth = 0;

// Aman dipanggil bersarang: hanya transaksi terluar yang BEGIN/COMMIT.
function transaction(fn) {
    if (txDepth > 0) return fn();
    db.exec('BEGIN');
    txDepth++;
    try {
        const result = fn();
        db.exec('COMMIT');
        return result;
    } catch (e) {
        try { db.exec('ROLLBACK'); } catch (_) {}
        throw e;
    } finally {
        txDepth--;
    }
}

// ─── Pengaturan per chat (model, mode, sesi aktif) ────────────────────────────

const qGetSettings = db.prepare('SELECT * FROM chat_settings WHERE chat_id = ?');
const qUpsertSettings = db.prepare(`
    INSERT INTO chat_settings (chat_id, model, mode, conversation_id, pending_alias, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(chat_id) DO UPDATE SET
        model = excluded.model,
        mode = excluded.mode,
        conversation_id = excluded.conversation_id,
        pending_alias = excluded.pending_alias,
        updated_at = excluded.updated_at
`);

function getChatSettings(chatId, defaults) {
    const row = qGetSettings.get(String(chatId));
    if (!row) return { ...defaults, conversationId: null, pendingAlias: null };
    return {
        model: row.model || defaults.model,
        mode: row.mode || defaults.mode,
        conversationId: row.conversation_id || null,
        pendingAlias: row.pending_alias || null,
    };
}

function saveChatSettings(chatId, s) {
    qUpsertSettings.run(
        String(chatId), s.model, s.mode,
        s.conversationId || null, s.pendingAlias || null, now()
    );
}

// ─── Alias sesi ───────────────────────────────────────────────────────────────

const qAllAliases = db.prepare('SELECT name, conversation_id FROM aliases');
const qUpsertAlias = db.prepare(`
    INSERT INTO aliases (name, conversation_id, created_at) VALUES (?, ?, ?)
    ON CONFLICT(name) DO UPDATE SET conversation_id = excluded.conversation_id
`);

function loadAliases() {
    const out = {};
    for (const r of qAllAliases.all()) out[r.name] = r.conversation_id;
    return out;
}

function saveAlias(name, conversationId) {
    qUpsertAlias.run(String(name).toLowerCase().trim(), conversationId, now());
}

// ─── Akun Google ──────────────────────────────────────────────────────────────

const qAccounts = db.prepare('SELECT * FROM accounts ORDER BY CAST(id AS INTEGER)');
const qUpsertAccount = db.prepare(`
    INSERT INTO accounts (id, email, name, access_token, refresh_token, token_type,
                          expires_in, expiry_timestamp, added_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
        email = excluded.email,
        name = excluded.name,
        access_token = excluded.access_token,
        refresh_token = excluded.refresh_token,
        token_type = excluded.token_type,
        expires_in = excluded.expires_in,
        expiry_timestamp = excluded.expiry_timestamp,
        updated_at = excluded.updated_at
`);
const qGetMeta = db.prepare('SELECT value FROM meta WHERE key = ?');
const qSetMeta = db.prepare(`
    INSERT INTO meta (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
`);

/** Mengembalikan { activeId, accounts } dengan bentuk yang sama seperti accounts.json lama. */
function loadAccountsData() {
    const accounts = {};
    for (const r of qAccounts.all()) {
        accounts[r.id] = {
            numericId: Number(r.id),
            email: r.email,
            name: r.name,
            addedAt: r.added_at,
            updatedAt: r.updated_at,
            token: {
                access_token: r.access_token,
                refresh_token: r.refresh_token,
                token_type: r.token_type || 'Bearer',
                expires_in: r.expires_in,
                expiry_timestamp: r.expiry_timestamp,
            },
        };
    }
    const metaRow = qGetMeta.get('active_account');
    let activeId = metaRow ? metaRow.value : null;
    if (!activeId || !accounts[activeId]) activeId = Object.keys(accounts)[0] || '1';
    return { activeId, accounts };
}

function saveAccountsData(data) {
    transaction(() => {
        const keep = Object.keys(data.accounts || {});
        for (const id of keep) {
            const a = data.accounts[id];
            const t = a.token || {};
            qUpsertAccount.run(
                String(id), a.email || 'unknown@google.com', a.name || null,
                t.access_token || null, t.refresh_token || null, t.token_type || 'Bearer',
                t.expires_in ?? null, t.expiry_timestamp ?? null,
                a.addedAt || now(), a.updatedAt || now()
            );
        }
        // hapus akun yang sudah tidak ada di data
        const existing = db.prepare('SELECT id FROM accounts').all().map(r => r.id);
        const del = db.prepare('DELETE FROM accounts WHERE id = ?');
        for (const id of existing) if (!keep.includes(id)) del.run(id);

        if (data.activeId != null) qSetMeta.run('active_account', String(data.activeId));
    });
}

// ─── Riwayat percakapan ───────────────────────────────────────────────────────

const qAddMessage = db.prepare(`
    INSERT INTO messages (chat_id, conversation_id, role, content, model, account_id, duration_ms, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);
const qMessagesByConvo = db.prepare(`
    SELECT * FROM (
        SELECT * FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?
    ) ORDER BY id ASC
`);
const qCountMessages = db.prepare('SELECT COUNT(*) AS n FROM messages');
const qCountMessagesByConvo = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?');

function addMessage({ chatId, conversationId, role, content, model, accountId, durationMs }) {
    qAddMessage.run(
        String(chatId), conversationId || null, role, String(content || ''),
        model || null, accountId != null ? String(accountId) : null,
        durationMs ?? null, now()
    );
}

/** Pesan terakhir (urut lama -> baru) dari sebuah sesi. */
function getMessages(conversationId, limit = 10) {
    if (!conversationId) return [];
    return qMessagesByConvo.all(conversationId, limit);
}

function countMessages(conversationId = null) {
    return conversationId
        ? qCountMessagesByConvo.get(conversationId).n
        : qCountMessages.get().n;
}

// ─── Daftar sesi milik Antigravity CLI (read-only, tanpa python3) ─────────────

function getAgySessions(agyDbPath) {
    if (!fs.existsSync(agyDbPath)) return [];
    let agy;
    try {
        try {
            agy = new DatabaseSync(agyDbPath, { readOnly: true });
        } catch (_) {
            agy = new DatabaseSync(agyDbPath);
        }
        return agy.prepare(
            'SELECT conversation_id AS id, title, step_count AS steps, last_modified_time AS time ' +
            'FROM conversation_summaries ORDER BY last_modified_time DESC'
        ).all().map(r => ({ id: r.id, title: r.title, steps: r.steps, time: r.time == null ? '' : String(r.time) }));
    } catch (e) {
        console.error('[db] Gagal membaca database sesi agy:', e.message);
        return [];
    } finally {
        try { if (agy) agy.close(); } catch (_) {}
    }
}

// ─── Migrasi satu kali dari file JSON lama ────────────────────────────────────

function readJson(file) {
    try {
        if (file && fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
        console.warn('[db] Tidak bisa membaca ' + file + ': ' + e.message);
    }
    return null;
}

function migrateFromJson({ aliasesFile, accountsFile, legacyAccountsFile }) {
    if (qGetMeta.get('json_migrated')) return;

    const aliases = readJson(aliasesFile);
    const accData = readJson(accountsFile);
    const legacy = !accData ? readJson(legacyAccountsFile) : null;

    transaction(() => {
        if (aliases) {
            for (const [name, id] of Object.entries(aliases)) qUpsertAlias.run(name, id, now());
        }
        if (accData && accData.accounts) {
            saveAccountsData({ activeId: accData.activeId, accounts: accData.accounts });
        } else if (legacy) {
            const ids = Object.keys(legacy);
            saveAccountsData({ activeId: ids[0] || '1', accounts: legacy });
        }
        qSetMeta.run('json_migrated', String(now()));
    });

    if (aliases || accData || legacy) {
        console.log('[db] Data JSON lama berhasil dimigrasikan ke SQLite (' + DB_PATH + ').');
    }
}

function dbInfo() {
    let size = 0;
    try { size = fs.statSync(DB_PATH).size; } catch (_) {}
    return { path: DB_PATH, sizeBytes: size, messages: countMessages() };
}

function close() {
    try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}
    try { db.close(); } catch (_) {}
}

module.exports = {
    DB_PATH,
    getChatSettings, saveChatSettings,
    loadAliases, saveAlias,
    loadAccountsData, saveAccountsData,
    addMessage, getMessages, countMessages,
    getAgySessions,
    migrateFromJson,
    dbInfo, close,
};
