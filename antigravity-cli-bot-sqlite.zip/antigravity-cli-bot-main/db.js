'use strict';
/**
 * db.js — Penyimpanan SQLite untuk Antigravity CLI Telegram Bot.
 *
 * Menggantikan:
 *   - session_aliases.json  -> tabel `aliases`
 *   - accounts.json         -> tabel `accounts` + `meta` (akun aktif)
 *   - state sesi di RAM     -> tabel `chat_settings` (tidak hilang saat bot restart)
 * Menambahkan:
 *   - tabel `messages`      -> riwayat percakapan bot (untuk /history & /export)
 *
 * Memakai modul bawaan Node.js `node:sqlite` (Node >= 22.5), jadi tanpa dependensi native.
 */

const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'bot.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
try { fs.chmodSync(DB_PATH, 0o600); } catch (_) {} // menyimpan refresh token -> batasi akses

db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS meta (
        key   TEXT PRIMARY KEY,
        value TEXT
    );

    CREATE TABLE IF NOT EXISTS chat_settings (
        chat_id         TEXT PRIMARY KEY,
        model           TEXT,
        mode            TEXT,
        conversation_id TEXT,
        pending_alias   TEXT,
        updated_at      INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS aliases (
        name            TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL,
        created_at      INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS accounts (
        id               TEXT PRIMARY KEY,
        email            TEXT NOT NULL,
        name             TEXT,
        access_token     TEXT,
        refresh_token    TEXT,
        token_type       TEXT DEFAULT 'Bearer',
        expires_in       INTEGER,
        expiry_timestamp INTEGER,
        added_at         INTEGER,
        updated_at       INTEGER
    );

    CREATE TABLE IF NOT EXISTS messages (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id         TEXT NOT NULL,
        conversation_id TEXT,
        role            TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
        content         TEXT NOT NULL,
        model           TEXT,
        account_id      TEXT,
        duration_ms     INTEGER,
        created_at      INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS uploads (
        chat_id    TEXT NOT NULL,
        message_id INTEGER NOT NULL,
        file_path  TEXT NOT NULL,
        file_name  TEXT NOT NULL,
        file_size  INTEGER,
        created_at INTEGER NOT NULL,
        PRIMARY KEY (chat_id, message_id)
    );
    CREATE TABLE IF NOT EXISTS tasks (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id          TEXT NOT NULL,
        conversation_id  TEXT,
        prompt           TEXT NOT NULL,
        model            TEXT,
        account          TEXT,
        status           TEXT NOT NULL DEFAULT 'running',
        tool_count       INTEGER NOT NULL DEFAULT 0,
        tokens           INTEGER,
        error            TEXT,
        response_preview TEXT,
        started_at       INTEGER NOT NULL,
        finished_at      INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_tasks_started ON tasks (started_at DESC);

    CREATE TABLE IF NOT EXISTS task_events (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id     INTEGER NOT NULL,
        step_index  INTEGER NOT NULL,
        kind        TEXT NOT NULL,
        tool        TEXT,
        icon        TEXT,
        title       TEXT,
        short       TEXT,
        target      TEXT,
        state       TEXT,
        ok          INTEGER,
        duration_ms INTEGER,
        params      TEXT,
        output      TEXT,
        started_ms  INTEGER NOT NULL,
        updated_ms  INTEGER NOT NULL,
        UNIQUE (task_id, step_index)
    );
    CREATE INDEX IF NOT EXISTS idx_events_task ON task_events (task_id, step_index);
    CREATE INDEX IF NOT EXISTS idx_messages_convo ON messages (conversation_id, id);
    CREATE INDEX IF NOT EXISTS idx_messages_chat  ON messages (chat_id, id);
`);

const now = () => Math.floor(Date.now() / 1000);

let txDepth = 0;

// Aman dipanggil bersarang: hanya transaksi terluar yang BEGIN/COMMIT.
function transaction(fn) {
    if (txDepth > 0) return fn();
    db.exec('BEGIN');
    txDepth++;
    try {
        const result = fn();
        db.exec('COMMIT');
        return result;
    } catch (e) {
        try { db.exec('ROLLBACK'); } catch (_) {}
        throw e;
    } finally {
        txDepth--;
    }
}

// ─── Pengaturan per chat (model, mode, sesi aktif) ────────────────────────────

const qGetSettings = db.prepare('SELECT * FROM chat_settings WHERE chat_id = ?');
const qUpsertSettings = db.prepare(`
    INSERT INTO chat_settings (chat_id, model, mode, conversation_id, pending_alias, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(chat_id) DO UPDATE SET
        model = excluded.model,
        mode = excluded.mode,
        conversation_id = excluded.conversation_id,
        pending_alias = excluded.pending_alias,
        updated_at = excluded.updated_at
`);

function getChatSettings(chatId, defaults) {
    const row = qGetSettings.get(String(chatId));
    if (!row) return { ...defaults, conversationId: null, pendingAlias: null };
    return {
        model: row.model || defaults.model,
        mode: row.mode || defaults.mode,
        conversationId: row.conversation_id || null,
        pendingAlias: row.pending_alias || null,
    };
}

function saveChatSettings(chatId, s) {
    qUpsertSettings.run(
        String(chatId), s.model, s.mode,
        s.conversationId || null, s.pendingAlias || null, now()
    );
}

// ─── Alias sesi ───────────────────────────────────────────────────────────────

const qAllAliases = db.prepare('SELECT name, conversation_id FROM aliases');
const qUpsertAlias = db.prepare(`
    INSERT INTO aliases (name, conversation_id, created_at) VALUES (?, ?, ?)
    ON CONFLICT(name) DO UPDATE SET conversation_id = excluded.conversation_id
`);

function loadAliases() {
    const out = {};
    for (const r of qAllAliases.all()) out[r.name] = r.conversation_id;
    return out;
}

function saveAlias(name, conversationId) {
    qUpsertAlias.run(String(name).toLowerCase().trim(), conversationId, now());
}

// ─── Akun Google ──────────────────────────────────────────────────────────────

const qAccounts = db.prepare('SELECT * FROM accounts ORDER BY CAST(id AS INTEGER)');
const qUpsertAccount = db.prepare(`
    INSERT INTO accounts (id, email, name, access_token, refresh_token, token_type,
                          expires_in, expiry_timestamp, added_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
        email = excluded.email,
        name = excluded.name,
        access_token = excluded.access_token,
        refresh_token = excluded.refresh_token,
        token_type = excluded.token_type,
        expires_in = excluded.expires_in,
        expiry_timestamp = excluded.expiry_timestamp,
        updated_at = excluded.updated_at
`);
const qGetMeta = db.prepare('SELECT value FROM meta WHERE key = ?');
const qSetMeta = db.prepare(`
    INSERT INTO meta (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
`);

/** Mengembalikan { activeId, accounts } dengan bentuk yang sama seperti accounts.json lama. */
function loadAccountsData() {
    const accounts = {};
    for (const r of qAccounts.all()) {
        accounts[r.id] = {
            numericId: Number(r.id),
            email: r.email,
            name: r.name,
            addedAt: r.added_at,
            updatedAt: r.updated_at,
            token: {
                access_token: r.access_token,
                refresh_token: r.refresh_token,
                token_type: r.token_type || 'Bearer',
                expires_in: r.expires_in,
                expiry_timestamp: r.expiry_timestamp,
            },
        };
    }
    const metaRow = qGetMeta.get('active_account');
    let activeId = metaRow ? metaRow.value : null;
    if (!activeId || !accounts[activeId]) activeId = Object.keys(accounts)[0] || '1';
    return { activeId, accounts };
}

function saveAccountsData(data) {
    transaction(() => {
        const keep = Object.keys(data.accounts || {});
        for (const id of keep) {
            const a = data.accounts[id];
            const t = a.token || {};
            qUpsertAccount.run(
                String(id), a.email || 'unknown@google.com', a.name || null,
                t.access_token || null, t.refresh_token || null, t.token_type || 'Bearer',
                t.expires_in ?? null, t.expiry_timestamp ?? null,
                a.addedAt || now(), a.updatedAt || now()
            );
        }
        // hapus akun yang sudah tidak ada di data
        const existing = db.prepare('SELECT id FROM accounts').all().map(r => r.id);
        const del = db.prepare('DELETE FROM accounts WHERE id = ?');
        for (const id of existing) if (!keep.includes(id)) del.run(id);

        if (data.activeId != null) qSetMeta.run('active_account', String(data.activeId));
    });
}

// ─── Riwayat percakapan ───────────────────────────────────────────────────────

const qAddMessage = db.prepare(`
    INSERT INTO messages (chat_id, conversation_id, role, content, model, account_id, duration_ms, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);
const qMessagesByConvo = db.prepare(`
    SELECT * FROM (
        SELECT * FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?
    ) ORDER BY id ASC
`);
const qCountMessages = db.prepare('SELECT COUNT(*) AS n FROM messages');
const qCountMessagesByConvo = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?');

function addMessage({ chatId, conversationId, role, content, model, accountId, durationMs }) {
    qAddMessage.run(
        String(chatId), conversationId || null, role, String(content || ''),
        model || null, accountId != null ? String(accountId) : null,
        durationMs ?? null, now()
    );
}

/** Pesan terakhir (urut lama -> baru) dari sebuah sesi. */
function getMessages(conversationId, limit = 10) {
    if (!conversationId) return [];
    return qMessagesByConvo.all(conversationId, limit);
}

function countMessages(conversationId = null) {
    return conversationId
        ? qCountMessagesByConvo.get(conversationId).n
        : qCountMessages.get().n;
}

// ─── Task & langkah tool (untuk Task Map) ─────────────────────────────────────

const qCreateTask = db.prepare(`
    INSERT INTO tasks (chat_id, prompt, model, account, status, started_at)
    VALUES (?, ?, ?, ?, 'running', ?)
`);
const TASK_COLUMNS = new Set(['conversation_id', 'status', 'tool_count', 'tokens', 'error', 'response_preview', 'finished_at']);
const qUpsertEvent = db.prepare(`
    INSERT INTO task_events (task_id, step_index, kind, tool, icon, title, short, target, state, ok,
                             duration_ms, params, output, started_ms, updated_ms)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(task_id, step_index) DO UPDATE SET
        kind = excluded.kind,
        tool = COALESCE(excluded.tool, task_events.tool),
        icon = COALESCE(excluded.icon, task_events.icon),
        title = COALESCE(excluded.title, task_events.title),
        short = COALESCE(excluded.short, task_events.short),
        target = COALESCE(excluded.target, task_events.target),
        state = excluded.state,
        ok = excluded.ok,
        duration_ms = COALESCE(excluded.duration_ms, task_events.duration_ms),
        params = COALESCE(excluded.params, task_events.params),
        output = COALESCE(excluded.output, task_events.output),
        updated_ms = excluded.updated_ms
`);
const qListTasks = db.prepare('SELECT * FROM tasks ORDER BY id DESC LIMIT ?');
const qGetTask = db.prepare('SELECT * FROM tasks WHERE id = ?');
const qTaskEvents = db.prepare('SELECT * FROM task_events WHERE task_id = ? ORDER BY step_index ASC LIMIT ?');

function createTask({ chatId, prompt, model, account }) {
    const r = qCreateTask.run(String(chatId), String(prompt || '').slice(0, 2000), model || null, account || null, Date.now());
    return Number(r.lastInsertRowid);
}

function updateTask(id, patch) {
    const keys = Object.keys(patch).filter(k => TASK_COLUMNS.has(k));
    if (!keys.length) return;
    db.prepare('UPDATE tasks SET ' + keys.map(k => k + ' = ?').join(', ') + ' WHERE id = ?')
        .run(...keys.map(k => patch[k] ?? null), id);
}

function upsertTaskEvent(taskId, e) {
    const t = Date.now();
    qUpsertEvent.run(
        taskId, e.stepIndex, e.kind, e.tool ?? null, e.icon ?? null, e.title ?? null, e.short ?? null,
        e.target ?? null, e.state ?? null, e.ok == null ? null : (e.ok ? 1 : 0),
        e.durationMs ?? null, e.params ?? null, e.output ?? null, t, t
    );
}

const listTasks = (limit = 12) => qListTasks.all(limit);
const getTask = (id) => qGetTask.get(id) || null;
const getTaskEvents = (id, limit = 200) => qTaskEvents.all(id, limit);

/** Task yang masih 'running' saat bot baru menyala = proses lama yang mati bersama bot. */
function failStaleTasks() {
    db.prepare(`UPDATE tasks SET status = 'interrupted', finished_at = ? WHERE status = 'running'`).run(Date.now());
}

function pruneTasks(keep = 60) {
    const cut = db.prepare('SELECT id FROM tasks ORDER BY id DESC LIMIT 1 OFFSET ?').get(keep);
    if (!cut) return;
    db.prepare('DELETE FROM task_events WHERE task_id <= ?').run(cut.id);
    db.prepare('DELETE FROM tasks WHERE id <= ?').run(cut.id);
}

// Kunci akses browser untuk mini app (dipakai bila dibuka lewat http://IP:PORT tanpa Telegram)
function getOrCreateWebKey() {
    const row = qGetMeta.get('webapp_key');
    if (row && row.value) return row.value;
    const key = require('crypto').randomBytes(18).toString('hex');
    qSetMeta.run('webapp_key', key);
    return key;
}

// ─── Lampiran file (untuk reply-ke-file, tahan restart) ──────────────────────

const qSaveUpload = db.prepare(`
    INSERT OR REPLACE INTO uploads (chat_id, message_id, file_path, file_name, file_size, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
`);
const qGetUpload = db.prepare('SELECT * FROM uploads WHERE chat_id = ? AND message_id = ?');

function saveUpload(chatId, messageId, f) {
    qSaveUpload.run(String(chatId), messageId, f.filePath, f.fileName, f.fileSize ?? null, now());
}

function getUpload(chatId, messageId) {
    const r = qGetUpload.get(String(chatId), messageId);
    return r ? { filePath: r.file_path, fileName: r.file_name, fileSize: r.file_size } : null;
}

// ─── Daftar sesi milik Antigravity CLI (read-only, tanpa python3) ─────────────

function getAgySessions(agyDbPath) {
    if (!fs.existsSync(agyDbPath)) return [];
    let agy;
    try {
        try {
            agy = new DatabaseSync(agyDbPath, { readOnly: true });
        } catch (_) {
            agy = new DatabaseSync(agyDbPath);
        }
        return agy.prepare(
            'SELECT conversation_id AS id, title, step_count AS steps, last_modified_time AS time ' +
            'FROM conversation_summaries ORDER BY last_modified_time DESC'
        ).all().map(r => ({ id: r.id, title: r.title, steps: r.steps, time: r.time == null ? '' : String(r.time) }));
    } catch (e) {
        console.error('[db] Gagal membaca database sesi agy:', e.message);
        return [];
    } finally {
        try { if (agy) agy.close(); } catch (_) {}
    }
}

// ─── Migrasi satu kali dari file JSON lama ────────────────────────────────────

function readJson(file) {
    try {
        if (file && fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
        console.warn('[db] Tidak bisa membaca ' + file + ': ' + e.message);
    }
    return null;
}

function migrateFromJson({ aliasesFile, accountsFile, legacyAccountsFile }) {
    if (qGetMeta.get('json_migrated')) return;

    const aliases = readJson(aliasesFile);
    const accData = readJson(accountsFile);
    const legacy = !accData ? readJson(legacyAccountsFile) : null;

    transaction(() => {
        if (aliases) {
            for (const [name, id] of Object.entries(aliases)) qUpsertAlias.run(name, id, now());
        }
        if (accData && accData.accounts) {
            saveAccountsData({ activeId: accData.activeId, accounts: accData.accounts });
        } else if (legacy) {
            const ids = Object.keys(legacy);
            saveAccountsData({ activeId: ids[0] || '1', accounts: legacy });
        }
        qSetMeta.run('json_migrated', String(now()));
    });

    if (aliases || accData || legacy) {
        console.log('[db] Data JSON lama berhasil dimigrasikan ke SQLite (' + DB_PATH + ').');
    }
}

function dbInfo() {
    let size = 0;
    try { size = fs.statSync(DB_PATH).size; } catch (_) {}
    return { path: DB_PATH, sizeBytes: size, messages: countMessages() };
}

function close() {
    try { db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}
    try { db.close(); } catch (_) {}
}

module.exports = {
    DB_PATH,
    getChatSettings, saveChatSettings,
    loadAliases, saveAlias,
    loadAccountsData, saveAccountsData,
    addMessage, getMessages, countMessages,
    saveUpload, getUpload,
    createTask, updateTask, upsertTaskEvent, listTasks, getTask, getTaskEvents, failStaleTasks, pruneTasks,
    getOrCreateWebKey,
    getAgySessions,
    migrateFromJson,
    dbInfo, close,
};
